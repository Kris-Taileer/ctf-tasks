Compile locally if you want to inspect the binary:

gcc chall.c -o chall -fno-stack-protector -no-pie -O0

For local runs, place `flag.txt` рядом с бинарем.
