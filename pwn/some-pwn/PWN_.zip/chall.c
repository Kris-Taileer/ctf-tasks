#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void setup(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    alarm(30);
}

void win(void) {
    FILE *f = fopen("flag.txt", "r");
    char flag[128];

    if (!f) {
        puts("flag.txt not found");
        exit(1);
    }

    if (!fgets(flag, sizeof(flag), f)) {
        puts("failed to read flag");
        fclose(f);
        exit(1);
    }

    fclose(f);
    puts("Access granted.");
    puts(flag);
}

int main(void) {
    char name[64];

    setup();
    puts("== Courier Terminal ==");
    printf("debug: win() is at %p\n", (void *)win);
    puts("Operator name:");
    gets(name);
    printf("Hello, %s\n", name);
    return 0;
}
