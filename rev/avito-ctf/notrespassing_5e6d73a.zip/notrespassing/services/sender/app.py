import os
import smtplib
from email.message import EmailMessage

from flask import Flask, jsonify, request

app = Flask(__name__)


def as_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/api/send", methods=["POST"])
def send_mail():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip()
    subject = (data.get("subject") or "MyOwnCloud notification").strip()
    body = data.get("body") or ""

    if not email:
        return jsonify({"success": False, "error": "email required"}), 400

    smtp_host = os.getenv("SMTP_HOST", "mailhog")
    smtp_port = int(os.getenv("SMTP_PORT", "1025"))
    smtp_user = os.getenv("SMTP_USER", "")
    smtp_password = os.getenv("SMTP_PASSWORD", "")
    smtp_use_tls = as_bool(os.getenv("SMTP_USE_TLS", "false"))
    from_email = os.getenv("MAIL_FROM_EMAIL", "noreply@cloudbox.local")

    msg = EmailMessage()
    msg["From"] = from_email
    msg["To"] = email
    msg["Subject"] = subject
    msg.set_content(body)

    implicit_ssl = smtp_port == 465 or as_bool(os.getenv("SMTP_IMPLICIT_SSL", "false"))

    try:
        if implicit_ssl:
            smtp_cls = lambda: smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=15)
        else:
            smtp_cls = lambda: smtplib.SMTP(smtp_host, smtp_port, timeout=15)

        with smtp_cls() as smtp:
            if not implicit_ssl and smtp_use_tls:
                smtp.starttls()
            if smtp_user:
                smtp.login(smtp_user, smtp_password)
            smtp.send_message(msg)
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500

    return jsonify({"success": True}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
