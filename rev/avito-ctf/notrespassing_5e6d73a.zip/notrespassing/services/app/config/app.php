<?php

return [
    'app_name' => 'MyOwnCloud',
    'sender_url' => getenv('SENDER_URL') ?: 'http://sender:5001',
];
