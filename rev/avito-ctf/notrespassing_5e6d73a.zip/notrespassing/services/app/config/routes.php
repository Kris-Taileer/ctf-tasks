<?php

use App\Controllers\AuthController;
use App\Controllers\FileController;
use App\Controllers\HomeController;
use App\Controllers\PasswordResetController;

return [
    ['GET', '/', [HomeController::class, 'index']],
    ['GET', '/dashboard', [HomeController::class, 'dashboard']],

    ['GET', '/login', [AuthController::class, 'showLogin']],
    ['POST', '/login', [AuthController::class, 'login']],
    ['GET', '/register', [AuthController::class, 'showRegister']],
    ['POST', '/register', [AuthController::class, 'register']],
    ['POST', '/logout', [AuthController::class, 'logout']],

    ['GET', '/files', [FileController::class, 'index']],
    ['POST', '/files/upload', [FileController::class, 'upload']],
    ['GET', '/files/download', [FileController::class, 'download']],
    ['POST', '/files/share', [FileController::class, 'share']],

    ['GET', '/password/forgot', [PasswordResetController::class, 'showForgot']],
    ['POST', '/password/forgot/request', [PasswordResetController::class, 'requestReset']],
    ['POST', '/password/forgot/finalize', [PasswordResetController::class, 'finalizeReset']],
    ['GET', '/password/reset', [PasswordResetController::class, 'showReset']],
    ['POST', '/password/reset', [PasswordResetController::class, 'resetPassword']],
    ['GET', '/password/change', [PasswordResetController::class, 'showChange']],
    ['POST', '/password/change', [PasswordResetController::class, 'changePassword']],
];
