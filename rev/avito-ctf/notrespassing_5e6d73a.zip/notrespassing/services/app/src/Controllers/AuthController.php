<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Models\User;
use Throwable;

final class AuthController extends BaseController
{
    public function showLogin(Request $request): void
    {
        $this->render('auth/login');
    }

    public function showRegister(Request $request): void
    {
        $this->render('auth/register');
    }

    public function login(Request $request): void
    {
        $email = strtolower((string) ($request->input('email') ?? ''));
        $password = (string) ($request->input('password') ?? '');
        if (!$email || !$password || strlen($email) < 9 || strlen($password) < 9) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Укажите почту и пароль (минимум 9 символов).'];
            $this->redirect('/login');
        }

        $userModel = new User($this->pdo);
        $user = $userModel->findByEmail($email);
        if (!$user || !password_verify($password, (string) $user['password_hash'])) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Неверная почта или пароль.'];
            $this->redirect('/login');
        }

        $_SESSION['user'] = [
            'id' => (int) $user['id'],
            'email' => (string) $user['email'],
        ];
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'С возвращением.'];
        $this->redirect('/dashboard');
    }

    public function register(Request $request): void
    {
        $email = strtolower((string) ($request->input('email') ?? ''));
        $password = (string) ($request->input('password') ?? '');
        if (
            !$email
            || !$password
            || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || strlen($email) < 9
            || strlen($password) < 9
        ) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Введите корректную почту и пароль (минимум 9 символов).'];
            $this->redirect('/register');
        }

        $userModel = new User($this->pdo);

        try {
            $userModel->create($email, $password);
        } catch (Throwable $e) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Пользователь с такой почтой уже существует.'];
            $this->redirect('/register');
        }

        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Регистрация завершена. Теперь войдите в аккаунт.'];
        $this->redirect('/login');
    }

    public function logout(Request $request): void
    {
        unset($_SESSION['user']);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Вы вышли из аккаунта.'];
        $this->redirect('/');
    }
}
