<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\View;
use PDO;

abstract class BaseController
{
    public function __construct(
        protected readonly PDO $pdo,
        protected readonly array $config
    ) {}

    protected function render(string $template, array $data = []): void
    {
        $data['currentUser'] = $_SESSION['user'] ?? null;
        $data['flash'] = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);

        View::render($template, $data);
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . $path);
        exit;
    }

    protected function requireAuth(): array
    {
        $user = $_SESSION['user'] ?? null;
        if (!$user) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Сначала войдите в аккаунт.'];
            $this->redirect('/login');
        }

        return $user;
    }
}
