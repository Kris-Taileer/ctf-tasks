<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;

final class HomeController extends BaseController
{
    public function index(Request $request): void
    {
        if (!empty($_SESSION['user'])) {
            $this->redirect('/dashboard');
        }

        $this->render('home');
    }

    public function dashboard(Request $request): void
    {
        $user = $this->requireAuth();
        $this->render('dashboard', ['user' => $user]);
    }
}
