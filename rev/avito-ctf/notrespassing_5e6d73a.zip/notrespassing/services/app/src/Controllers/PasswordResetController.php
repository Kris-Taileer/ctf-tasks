<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Models\PasswordReset;
use App\Models\User;
use App\Services\MailerService;

final class PasswordResetController extends BaseController
{
    private const IMMUTABLE_USER_EMAIL = 'admin@cloudbox.local';

    public function showForgot(Request $request): void
    {
        $pendingEmail = $_SESSION['contact_email'] ?? null;
        $pendingResetUserId = $_SESSION['reset_user_id'] ?? null;

        $this->render('password/forgot', [
            'pendingEmail' => $pendingEmail,
            'pendingResetUserId' => $pendingResetUserId,
            'maskedEmail' => $pendingEmail ? $this->maskEmail((string) $pendingEmail) : null,
        ]);
    }

    private function maskEmail(string $email): string
    {
        $parts = explode('@', $email, 2);
        $local = $parts[0] ?? '';
        $domain = $parts[1] ?? '';
        $maskedLocal = $local === '' ? '' : substr($local, 0, 1) . '•••';

        return $domain === '' ? $maskedLocal : $maskedLocal . '@' . $domain;
    }

    public function requestReset(Request $request): void
    {
        $email = strtolower(trim((string) ($request->input('email') ?? '')));
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) < 9) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Введите корректную почту (минимум 9 символов).'];
            $this->redirect('/password/forgot');
        }

        $user = (new User($this->pdo))->findByEmail($email);
        if (!$user) {
            unset($_SESSION['reset_user_id']);
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Пользователь с такой почтой не найден.'];
            $this->redirect('/password/forgot');
        }

        $_SESSION['contact_email'] = $email;
        $_SESSION['reset_user_id'] = (int) $user['id'];
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Запрос готов. Отправляем код на вашу почту.'];
        $this->redirect('/password/forgot');
    }

    public function finalizeReset(Request $request): void
    {
        $resetUserId = (int) ($_SESSION['reset_user_id'] ?? 0);
        $email = (string) ($_SESSION['contact_email'] ?? '');
        if ($resetUserId < 1 || $email === '') {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Нет активного запроса на восстановление.'];
            $this->redirect('/password/forgot');
        }

        $token = (new PasswordReset($this->pdo))->createToken($resetUserId);

        $rawForwardedProto = (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '');
        $forwardedProto = strtolower(trim(explode(',', $rawForwardedProto)[0] ?? ''));
        if ($forwardedProto === 'http' || $forwardedProto === 'https') {
            $scheme = $forwardedProto;
        } else {
            $https = strtolower((string) ($_SERVER['HTTPS'] ?? ''));
            $scheme = ($https !== '' && $https !== 'off') ? 'https' : 'http';
        }
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost')));
        $base = $scheme . '://' . $host;
        $link = rtrim($base, '/') . '/password/reset?token=' . urlencode($token);

        $mailer = new MailerService((string) $this->config['sender_url']);
        $mailer->send(
            $email,
            'MyOwnCloud: сброс пароля',
            "Токен сброса: {$token}\nСсылка для сброса: {$link}\nТокен действует 30 минут."
        );

        unset($_SESSION['reset_user_id']);
        $_SESSION['flash'] = ['type' => 'success', 'text' => '✅󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅧󠅕󠅜󠅓󠅟󠅝󠅕󠅙󠅞󠄝󠄡󠅒󠄨󠅞󠅨󠄦󠄤󠅟󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟 Код для сброса отправлен. Проверьте почту.'];
        $this->redirect('/password/forgot');
    }

    public function showReset(Request $request): void
    {
        $token = (string) ($request->query('token') ?? '');
        $this->render('password/reset', ['token' => $token]);
    }

    public function resetPassword(Request $request): void
    {
        $token = (string) ($request->input('token') ?? '');
        $password = (string) ($request->input('password') ?? '');
        if ($token === '' || strlen($password) < 9) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Нужны токен и надежный пароль (минимум 9 символов).'];
            $this->redirect('/password/reset?token=' . urlencode($token));
        }

        $resetModel = new PasswordReset($this->pdo);
        $resetRecord = $resetModel->findValidToken($token);
        if (!$resetRecord) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Токен недействителен или истек.'];
            $this->redirect('/password/reset?token=' . urlencode($token));
        }

        $userId = (int) $resetRecord['user_id'];
        (new User($this->pdo))->setPassword($userId, $password);
        $resetModel->invalidateForUser($userId);

        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Пароль изменен. Теперь можно войти.'];
        $this->redirect('/login');
    }

    public function showChange(Request $request): void
    {
        $this->requireMutableUser();
        $this->render('password/change');
    }

    public function changePassword(Request $request): void
    {
        $user = $this->requireMutableUser();
        $currentPassword = (string) ($request->input('current_password') ?? '');
        $newPassword = (string) ($request->input('new_password') ?? '');
        $passwordConfirmation = (string) ($request->input('password_confirmation') ?? '');

        if ($currentPassword === '' || strlen($newPassword) < 9) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Укажите текущий и новый пароль (минимум 9 символов).'];
            $this->redirect('/password/change');
        }

        if ($newPassword !== $passwordConfirmation) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Новые пароли не совпадают.'];
            $this->redirect('/password/change');
        }

        $userModel = new User($this->pdo);
        $storedUser = $userModel->findById((int) $user['id']);
        if (!$storedUser || !$userModel->checkPassword($storedUser, $currentPassword)) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Текущий пароль указан неверно.'];
            $this->redirect('/password/change');
        }

        $userModel->setPassword((int) $user['id'], $newPassword);
        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Пароль успешно изменен.'];
        $this->redirect('/dashboard');
    }

    private function requireMutableUser(): array
    {
        $user = $this->requireAuth();
        if (strtolower((string) ($user['email'] ?? '')) === self::IMMUTABLE_USER_EMAIL) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Смена пароля для этого аккаунта недоступна.'];
            $this->redirect('/dashboard');
        }

        return $user;
    }
}
