<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Models\FileItem;
use App\Models\Share;
use App\Models\User;
use App\Services\MailerService;
use App\Services\StorageService;

final class FileController extends BaseController
{
    public function index(Request $request): void
    {
        $user = $this->requireAuth();
        $files = (new FileItem($this->pdo))->listByUser((int) $user['id']);
        $sharedWithMe = (new Share($this->pdo))->listForRecipient((string) $user['email']);

        $this->render('files/index', [
            'files' => $files,
            'sharedWithMe' => $sharedWithMe,
            'contactEmail' => $_SESSION['contact_email'] ?? '',
        ]);
    }

    public function upload(Request $request): void
    {
        $user = $this->requireAuth();
        if (strtolower((string) $user['email']) === 'admin@cloudbox.local') {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Загрузка файлов недоступна для этого аккаунта.'];
            $this->redirect('/files');
        }

        $upload = $request->file('upload');
        if (!$upload) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Сначала выберите файл.'];
            $this->redirect('/files');
        }

        $storage = new StorageService();
        $stored = $storage->storeUploadedFile((int) $user['id'], $upload);
        if (!$stored) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Не удалось загрузить файл.'];
            $this->redirect('/files');
        }

        (new FileItem($this->pdo))->create(
            (int) $user['id'],
            (string) $stored['original_name'],
            (string) $stored['stored_name'],
            (int) $stored['size_bytes']
        );

        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Файл успешно загружен.'];
        $this->redirect('/files');
    }

    public function download(Request $request): void
    {
        $user = $this->requireAuth();
        $fileId = (int) ($request->query('id') ?? '0');
        $fileModel = new FileItem($this->pdo);
        $record = $fileModel->findOwnedById($fileId, (int) $user['id']);

        if (!$record && (new Share($this->pdo))->isSharedWith($fileId, (string) $user['email'])) {
            $record = $fileModel->findById($fileId);
        }

        if (!$record) {
            http_response_code(404);
            echo 'Файл не найден';
            return;
        }

        $path = (new StorageService())->absolutePath((int) $record['user_id'], (string) $record['stored_name']);
        if (!is_file($path)) {
            http_response_code(404);
            echo 'Файл отсутствует на диске';
            return;
        }

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $record['original_name'] . '"');

        readfile($path);
    }

    public function share(Request $request): void
    {
        $user = $this->requireAuth();
        $fileId = (int) ($request->input('file_id') ?? '0');
        $recipient = strtolower(trim((string) ($request->input('email') ?? '')));

        if (!$recipient || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Введите корректную почту получателя.'];
            $this->redirect('/files');
        }

        if ($recipient === strtolower((string) $user['email'])) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Нельзя открыть доступ самому себе.'];
            $this->redirect('/files');
        }

        $recipientUser = (new User($this->pdo))->findByEmail($recipient);
        if (!$recipientUser) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Пользователь с такой почтой не найден.'];
            $this->redirect('/files');
        }

        $file = (new FileItem($this->pdo))->findOwnedById($fileId, (int) $user['id']);
        if (!$file) {
            $_SESSION['flash'] = ['type' => 'error', 'text' => 'Файл не найден.'];
            $this->redirect('/files');
        }

        if ($recipient !== 'admin@cloudbox.local') {
            (new Share($this->pdo))->create($fileId, (int) $user['id'], $recipient);

            $mailer = new MailerService((string) $this->config['sender_url']);
            $mailer->send(
                $recipient,
                'MyOwnCloud: вам открыли доступ к файлу',
                "Пользователь {$user['email']} открыл вам доступ к файлу {$file['original_name']}. Он доступен во вкладке «Файлы»."
            );
        }

        $_SESSION['contact_email'] = $recipient;

        $_SESSION['flash'] = ['type' => 'success', 'text' => 'Доступ открыт, получателю отправлено письмо.'];
        $this->redirect('/files');
    }
}
