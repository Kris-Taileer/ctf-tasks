<?php

declare(strict_types=1);

session_start();

define('APP_ROOT', dirname(__DIR__));

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    $baseDir = APP_ROOT . '/src/';
    if (strncmp($prefix, $class, strlen($prefix)) !== 0) {
        return;
    }

    $relativeClass = substr($class, strlen($prefix));
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

$config = require APP_ROOT . '/config/app.php';
$dbPath = APP_ROOT . '/data/database.sqlite';
$dsn = 'sqlite:' . $dbPath;

if (!is_dir(dirname($dbPath))) {
    mkdir(dirname($dbPath), 0775, true);
}

$pdo = new PDO($dsn);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

$pdo->exec('
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
');

$pdo->exec('
    CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        is_immutable INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
');

$pdo->exec('
    CREATE TABLE IF NOT EXISTS shares (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_id INTEGER NOT NULL,
        sender_user_id INTEGER NOT NULL,
        recipient_email TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(file_id) REFERENCES files(id),
        FOREIGN KEY(sender_user_id) REFERENCES users(id)
    );
');

$pdo->exec('
    CREATE TABLE IF NOT EXISTS password_resets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        created_at TEXT NOT NULL,
        used_at TEXT DEFAULT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
');

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
$stmt->execute(['email' => 'admin@cloudbox.local']);
$admin = $stmt->fetch();

if (!$admin) {
    $adminPassword = getenv('ADMIN_PASSWORD') ?: bin2hex(random_bytes(16));
    $createAdmin = $pdo->prepare(
        'INSERT INTO users (email, password_hash, created_at) VALUES (:email, :password_hash, :created_at)'
    );
    $createAdmin->execute([
        'email' => 'admin@cloudbox.local',
        'password_hash' => password_hash($adminPassword, PASSWORD_DEFAULT),
        'created_at' => gmdate('c'),
    ]);
    $adminId = (int) $pdo->lastInsertId();
} else {
    $adminId = (int) $admin['id'];
}

$adminStorageDir = APP_ROOT . '/storage/uploads/' . $adminId;
if (!is_dir($adminStorageDir)) {
    mkdir($adminStorageDir, 0775, true);
}

$flagRecord = $pdo->prepare('SELECT id FROM files WHERE user_id = :user_id AND is_immutable = 1 LIMIT 1');
$flagRecord->execute(['user_id' => $adminId]);

if (!$flagRecord->fetch()) {
    $flagValue = trim((string) @file_get_contents('/flag'));
    if ($flagValue === '') {
        $flagValue = getenv('FLAG') ?: 'avito{dev_flag_replace_me}';
    }

    $schemaFilename = 'wiring-diagram.txt';
    $storedName = bin2hex(random_bytes(12)) . '.txt';
    $fullPath = $adminStorageDir . '/' . $storedName;
    file_put_contents($fullPath, $flagValue . PHP_EOL);

    $createFile = $pdo->prepare(
        'INSERT INTO files (user_id, original_name, stored_name, size_bytes, is_immutable, created_at)
         VALUES (:user_id, :original_name, :stored_name, :size_bytes, :is_immutable, :created_at)'
    );
    $createFile->execute([
        'user_id' => $adminId,
        'original_name' => $schemaFilename,
        'stored_name' => $storedName,
        'size_bytes' => filesize($fullPath) ?: strlen($flagValue),
        'is_immutable' => 1,
        'created_at' => gmdate('c'),
    ]);
}

return [
    'config' => $config,
    'pdo' => $pdo,
];
