<div class="grid-two">
    <div class="panel">
        <h3>Загрузка файла</h3>
        <form method="POST" action="/files/upload" enctype="multipart/form-data">
            <input type="file" name="upload" required>
            <button class="primary" type="submit">Загрузить</button>
        </form>
    </div>

    <div class="panel">
        <h3>Поделиться по email</h3>
        <form method="POST" action="/files/share">
            <label>Файл</label>
            <select name="file_id" required>
                <option value="">Выберите файл</option>
                <?php foreach ($files as $f): ?>
                    <option value="<?= (int) $f['id'] ?>"><?= htmlspecialchars((string) $f['original_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <label>Почта получателя</label>
            <input type="email" name="email" placeholder="admin@cloudbox.local" value="<?= htmlspecialchars((string) ($contactEmail ?? '')) ?>" required>
            <button class="primary" type="submit">Открыть доступ</button>
        </form>
    </div>
</div>

<div class="panel">
    <h3>Ваши файлы</h3>
    <table class="files">
        <thead>
            <tr>
                <th>Имя</th>
                <th>Размер</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($files as $f): ?>
            <tr>
                <td><?= htmlspecialchars((string) $f['original_name']) ?></td>
                <td><?= (int) $f['size_bytes'] ?> байт</td>
                <td><a href="/files/download?id=<?= (int) $f['id'] ?>">Скачать</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if (!empty($sharedWithMe)): ?>
<div class="panel">
    <h3>Открыт доступ для вас</h3>
    <table class="files">
        <thead>
            <tr>
                <th>Имя</th>
                <th>Владелец</th>
                <th>Размер</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($sharedWithMe as $f): ?>
            <tr>
                <td><?= htmlspecialchars((string) $f['original_name']) ?></td>
                <td><?= htmlspecialchars((string) $f['owner_email']) ?></td>
                <td><?= (int) $f['size_bytes'] ?> байт</td>
                <td><a href="/files/download?id=<?= (int) $f['id'] ?>">Скачать</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
