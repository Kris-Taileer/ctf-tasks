<div class="panel" style="max-width:580px;">
    <h3>Установить новый пароль</h3>
    <form method="POST" action="/password/reset">
        <label>Токен сброса</label>
        <input type="text" name="token" value="<?= htmlspecialchars((string) $token) ?>" required>
        <label>Новый пароль</label>
        <input type="password" name="password" minlength="9" required>
        <button class="primary" type="submit">Обновить пароль</button>
    </form>
</div>
