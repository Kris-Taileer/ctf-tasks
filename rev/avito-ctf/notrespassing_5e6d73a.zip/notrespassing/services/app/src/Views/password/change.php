<div class="panel" style="max-width:580px;">
    <h3>Сменить пароль</h3>
    <form method="POST" action="/password/change">
        <label>Текущий пароль</label>
        <input type="password" name="current_password" autocomplete="current-password" required>
        <label>Новый пароль</label>
        <input type="password" name="new_password" minlength="9" autocomplete="new-password" required>
        <label>Повторите новый пароль</label>
        <input type="password" name="password_confirmation" minlength="9" autocomplete="new-password" required>
        <button class="primary" type="submit">Сменить пароль</button>
    </form>
</div>
