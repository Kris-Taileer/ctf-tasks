<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>MyOwnCloud</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap");

        :root {
            --bg: #ffffff;
            --bg-soft: #f6f7f9;
            --panel: #ffffff;
            --panel-soft: #f2f4f7;
            --text: #0b0d10;
            --muted: #5b626d;
            --line: #e7eaee;
            --line-strong: #c8cdd4;
            --accent: #1e66ff;
            --accent-hover: #1856d6;
            --accent-soft: #e6efff;
            --accent-ink: #163f97;
            --ok: #1f6d4a;
            --danger: #ad3421;
            --radius: 14px;
            --radius-sm: 10px;
        }

        * { box-sizing: border-box; }

        html, body { background: var(--bg); }

        body {
            margin: 0;
            font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
            font-feature-settings: "ss01", "cv11";
        }

        .app {
            max-width: 880px;
            margin: 0 auto;
            padding: 32px 22px 80px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            padding: 0 0 22px;
            margin-bottom: 28px;
            border-bottom: 1px solid var(--line);
        }

        .brand-wrap { min-width: 0; }

        .brand {
            color: var(--text);
            text-decoration: none;
            font-size: 19px;
            font-weight: 600;
            letter-spacing: -0.01em;
            display: inline-flex;
            align-items: center;
            gap: 9px;
        }

        .brand::before {
            content: "";
            width: 9px;
            height: 9px;
            border-radius: 2px;
            background: var(--accent);
        }

        .brand-sub {
            margin: 2px 0 0 18px;
            color: var(--muted);
            font-size: 13px;
        }

        .nav {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
            justify-content: flex-end;
            align-items: center;
        }

        .nav form { margin: 0; }

        .nav a, .nav button {
            color: var(--text);
            text-decoration: none;
            border: 1px solid transparent;
            background: transparent;
            border-radius: 8px;
            padding: 7px 10px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color .12s ease, color .12s ease;
        }

        .nav a:hover, .nav button:hover {
            background: var(--panel-soft);
        }

        .nav .current {
            color: var(--accent-ink);
        }

        .meta-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 14px;
        }

        .meta-label {
            margin: 0;
            color: var(--muted);
            font-size: 12px;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        .user-pill {
            border: 1px solid var(--line);
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            color: var(--text);
            background: var(--panel);
        }

        .panel {
            border: 1px solid var(--line);
            border-radius: var(--radius);
            background: var(--panel);
            padding: 22px 24px;
            margin-top: 14px;
        }

        .panel.soft { background: var(--panel-soft); }

        .panel.flat { border: none; padding: 0; margin-top: 18px; }

        h1, h2, h3 {
            margin: 0 0 12px;
            color: var(--text);
            letter-spacing: -0.02em;
        }

        h1 {
            font-size: 40px;
            line-height: 1.1;
            font-weight: 650;
            max-width: 18ch;
        }

        h2 {
            font-size: 26px;
            line-height: 1.18;
            font-weight: 620;
        }

        h3 {
            font-size: 17px;
            font-weight: 600;
        }

        p {
            margin: 0 0 12px;
            color: var(--muted);
            line-height: 1.6;
            max-width: 62ch;
            font-size: 15px;
        }

        .lead {
            font-size: 17px;
            line-height: 1.55;
            color: #2a2f38;
            max-width: 56ch;
        }

        a { color: var(--accent-ink); text-underline-offset: 3px; }

        .flash {
            border-radius: var(--radius-sm);
            padding: 10px 13px;
            margin: 0 0 14px;
            border: 1px solid var(--line);
            background: var(--panel);
            font-size: 14px;
        }

        .flash.error { color: var(--danger); border-color: #f3c7be; background: #fdeee9; }
        .flash.success { color: var(--ok); border-color: #cde4d6; background: #edf5ef; }

        .grid-two {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        form { display: grid; gap: 10px; }

        label {
            font-size: 13px;
            color: var(--text);
            font-weight: 550;
            margin-top: 2px;
        }

        input, select, button {
            width: 100%;
            border: 1px solid var(--line);
            border-radius: var(--radius-sm);
            background: var(--panel);
            color: var(--text);
            padding: 10px 12px;
            font-size: 15px;
            font-family: inherit;
            outline: none;
            transition: border-color .12s ease, box-shadow .12s ease;
        }

        input::placeholder { color: #9ba1ab; }

        input:focus, select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(30, 102, 255, 0.14);
        }

        button { cursor: pointer; }

        button.primary {
            border: 1px solid var(--accent);
            background: var(--accent);
            color: #ffffff;
            font-weight: 600;
            padding: 11px 13px;
            font-size: 14px;
        }
        button.primary:hover {
            background: var(--accent-hover);
            border-color: var(--accent-hover);
        }

        .cta-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .btn {
            width: auto;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            border: 1px solid var(--accent);
            background: var(--accent);
            color: #ffffff;
        }
        .btn:hover { background: var(--accent-hover); border-color: var(--accent-hover); color: #ffffff; }

        .btn.ghost {
            background: transparent;
            color: var(--text);
            border-color: var(--line-strong);
        }
        .btn.ghost:hover { background: var(--panel-soft); color: var(--text); }

        .files {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        .files th, .files td {
            text-align: left;
            padding: 11px 8px;
            border-bottom: 1px solid var(--line);
        }

        .files th {
            color: var(--muted);
            font-size: 12px;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            font-weight: 600;
        }

        .files tr:hover td { background: var(--panel-soft); }

        .tag {
            display: inline-block;
            border: 1px solid var(--accent-soft);
            border-radius: 999px;
            padding: 2px 9px;
            font-size: 12px;
            color: var(--accent-ink);
            background: var(--accent-soft);
            font-weight: 550;
        }

        .mini-note {
            color: var(--muted);
            font-size: 13px;
            margin-top: 16px;
        }

        .mini-note a { color: var(--accent-ink); }

        .footer {
            margin-top: 42px;
            padding-top: 18px;
            border-top: 1px solid var(--line);
            color: var(--muted);
            font-size: 13px;
        }

        .footer p { margin: 0 0 4px; color: var(--muted); }
        .footer p.sub { font-size: 12px; color: #8b90a0; }

        @media (max-width: 780px) {
            .topbar { flex-direction: column; align-items: flex-start; }
            .nav { width: 100%; justify-content: flex-start; }
            .grid-two { grid-template-columns: 1fr; }
            h1 { font-size: 32px; }
        }
    </style>
</head>
<body>
<div class="app">
    <header class="topbar">
        <div class="brand-wrap">
            <a class="brand" href="/">MyOwnCloud</a>
            <p class="brand-sub">подвальное облако — тихо работает, никуда не спешит</p>
        </div>
        <nav class="nav">
            <?php if (!empty($currentUser)): ?>
                <a href="/dashboard">Обзор</a>
                <a href="/files">Файлы</a>
                <?php if (strtolower((string) ($currentUser['email'] ?? '')) !== 'admin@cloudbox.local'): ?>
                    <a href="/password/change">Сменить пароль</a>
                <?php endif; ?>
                <form method="POST" action="/logout">
                    <button type="submit">Выйти</button>
                </form>
            <?php else: ?>
                <a href="/login">Вход</a>
                <a href="/register">Регистрация</a>
                <a href="/password/forgot">Забыли пароль?</a>
            <?php endif; ?>
        </nav>
    </header>

    <?php if (!empty($currentUser)): ?>
        <div class="meta-row">
            <p class="meta-label">Рабочее пространство</p>
            <span class="user-pill"><?= htmlspecialchars((string) $currentUser['email']) ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($flash)): ?>
        <div class="flash <?= htmlspecialchars((string) $flash['type']) ?>">
            <?= htmlspecialchars((string) $flash['text']) ?>
        </div>
    <?php endif; ?>

    <?= $content ?>

    <footer class="footer">
        <p>MyOwnCloud · держится на двух патчкордах и здравом смысле</p>
        <p class="sub">Сервер в подвале, питание резервное, админ — Иваныч.</p>
    </footer>
</div>
</body>
</html>
