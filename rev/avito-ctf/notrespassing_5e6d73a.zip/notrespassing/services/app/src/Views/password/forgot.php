<div class="panel">
    <h3>Восстановление пароля</h3>
    <p>Укажите почту, с которой вы регистрировались. Мы подготовим запрос и отправим на нее одноразовый код.</p>

    <form method="POST" action="/password/forgot/request" style="max-width:520px;">
        <label>Почта</label>
        <input type="email" name="email" minlength="9" value="<?= htmlspecialchars((string) ($pendingEmail ?? '')) ?>" required>
        <button class="primary" type="submit">Продолжить</button>
    </form>

    <?php if (!empty($pendingResetUserId)): ?>
        <div class="panel soft" style="margin-top:14px;">
            <p>Запрос готов. Отправляем ссылку для восстановления на <b><?= htmlspecialchars((string) ($maskedEmail ?? '')) ?></b>…</p>
            <form id="finalize-reset-form" method="POST" action="/password/forgot/finalize"></form>
            <script>document.getElementById('finalize-reset-form').submit();</script>
        </div>
    <?php endif; ?>
</div>
