<div class="panel" style="max-width:520px;">
    <h2>Регистрация</h2>
    <form method="POST" action="/register">
        <label>Почта</label>
        <input type="email" name="email" minlength="9" required>
        <label>Пароль</label>
        <input type="password" name="password" minlength="9" required>
        <button class="primary" type="submit">Создать аккаунт</button>
    </form>
</div>
