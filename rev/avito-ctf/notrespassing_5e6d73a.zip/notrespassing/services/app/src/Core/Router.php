<?php

declare(strict_types=1);

namespace App\Core;

use PDO;

final class Router
{
    private array $routes = [];

    public function __construct(
        private readonly PDO $pdo,
        private readonly array $config
    ) {}

    public function add(string $method, string $path, array $handler): void
    {
        $this->routes[strtoupper($method)][$path] = $handler;
    }

    public function dispatch(Request $request): void
    {
        $method = $request->method();
        $path = $request->path();
        $handler = $this->routes[$method][$path] ?? null;

        if ($handler === null) {
            http_response_code(404);
            echo '❌󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅧󠅕󠅜󠅓󠅟󠅝󠅕󠅙󠅞󠄝󠄡󠅒󠄨󠅞󠅨󠄦󠄤󠅟󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟 Not Found';
            return;
        }

        [$controllerClass, $action] = $handler;
        $controller = new $controllerClass($this->pdo, $this->config);
        $controller->{$action}($request);
    }
}
