<?php

declare(strict_types=1);

namespace App\Services;

final class StorageService
{
    public function userDir(int $userId): string
    {
        $dir = APP_ROOT . '/storage/uploads/' . $userId;
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        return $dir;
    }

    public function storeUploadedFile(int $userId, array $file): ?array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return null;
        }

        $originalName = basename((string) ($file['name'] ?? 'file.bin'));
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $storedName = bin2hex(random_bytes(12)) . ($extension ? '.' . $extension : '');
        $target = $this->userDir($userId) . '/' . $storedName;

        if (!move_uploaded_file((string) $file['tmp_name'], $target)) {
            return null;
        }

        return [
            'original_name' => $originalName,
            'stored_name' => $storedName,
            'size_bytes' => filesize($target) ?: 0,
            'path' => $target,
        ];
    }

    public function absolutePath(int $userId, string $storedName): string
    {
        return $this->userDir($userId) . '/' . $storedName;
    }
}
