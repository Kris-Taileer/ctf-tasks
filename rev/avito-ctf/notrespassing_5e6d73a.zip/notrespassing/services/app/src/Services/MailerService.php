<?php

declare(strict_types=1);

namespace App\Services;

final class MailerService
{
    public function __construct(private readonly string $senderUrl) {}

    public function send(string $email, string $subject, string $body): bool
    {
        $payload = json_encode([
            'email' => $email,
            'subject' => $subject,
            'body' => $body,
        ], JSON_THROW_ON_ERROR);

        $ch = curl_init(rtrim($this->senderUrl, '/') . '/api/send');
        if ($ch === false) {
            return false;
        }

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_TIMEOUT => 5,
        ]);

        curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $httpCode >= 200 && $httpCode < 300;
    }
}
