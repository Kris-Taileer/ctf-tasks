<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

final class FileItem
{
    public function __construct(private readonly PDO $pdo) {}

    public function create(int $userId, string $originalName, string $storedName, int $sizeBytes): bool
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO files (user_id, original_name, stored_name, size_bytes, is_immutable, created_at)
             VALUES (:user_id, :original_name, :stored_name, :size_bytes, 0, :created_at)'
        );

        return $stmt->execute([
            'user_id' => $userId,
            'original_name' => $originalName,
            'stored_name' => $storedName,
            'size_bytes' => $sizeBytes,
            'created_at' => gmdate('c'),
        ]);
    }

    public function listByUser(int $userId): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, original_name, size_bytes, is_immutable, created_at
             FROM files
             WHERE user_id = :user_id
             ORDER BY id DESC'
        );
        $stmt->execute(['user_id' => $userId]);

        return $stmt->fetchAll() ?: [];
    }

    public function findOwnedById(int $id, int $userId): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM files WHERE id = :id AND user_id = :user_id LIMIT 1');
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        $result = $stmt->fetch();

        return $result ?: null;
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM files WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch();

        return $result ?: null;
    }
}
