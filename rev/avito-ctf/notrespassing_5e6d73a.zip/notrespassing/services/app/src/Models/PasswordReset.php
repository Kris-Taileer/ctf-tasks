<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

final class PasswordReset
{
    public function __construct(private readonly PDO $pdo) {}

    public function createToken(int $userId): string
    {
        $token = bin2hex(random_bytes(24));
        $stmt = $this->pdo->prepare(
            'INSERT INTO password_resets (user_id, token, created_at, used_at)
             VALUES (:user_id, :token, :created_at, NULL)'
        );
        $stmt->execute([
            'user_id' => $userId,
            'token' => $token,
            'created_at' => gmdate('c'),
        ]);

        return $token;
    }

    public function findValidToken(string $token): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT * FROM password_resets WHERE token = :token AND used_at IS NULL LIMIT 1'
        );
        $stmt->execute(['token' => trim($token)]);
        $record = $stmt->fetch();

        if (!$record) {
            return null;
        }

        $createdTs = strtotime((string) $record['created_at']);
        if ($createdTs === false || (time() - $createdTs) > 1800) {
            return null;
        }

        return $record;
    }

    public function invalidateForUser(int $userId): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE password_resets
             SET used_at = :used_at
             WHERE user_id = :user_id AND used_at IS NULL'
        );
        $stmt->execute([
            'user_id' => $userId,
            'used_at' => gmdate('c'),
        ]);
    }
}
