<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

final class Share
{
    public function __construct(private readonly PDO $pdo) {}

    public function create(int $fileId, int $senderUserId, string $recipientEmail): bool
    {
        $stmt = $this->pdo->prepare(
            'INSERT INTO shares (file_id, sender_user_id, recipient_email, created_at)
             VALUES (:file_id, :sender_user_id, :recipient_email, :created_at)'
        );

        return $stmt->execute([
            'file_id' => $fileId,
            'sender_user_id' => $senderUserId,
            'recipient_email' => strtolower(trim($recipientEmail)),
            'created_at' => gmdate('c'),
        ]);
    }

    public function listForRecipient(string $recipientEmail): array
    {
        $stmt = $this->pdo->prepare(
            'SELECT f.id, f.original_name, f.size_bytes, u.email AS owner_email
             FROM shares s
             JOIN files f ON f.id = s.file_id
             JOIN users u ON u.id = f.user_id
             WHERE s.recipient_email = :email
             GROUP BY f.id
             ORDER BY s.id DESC'
        );
        $stmt->execute(['email' => strtolower(trim($recipientEmail))]);

        return $stmt->fetchAll() ?: [];
    }

    public function isSharedWith(int $fileId, string $recipientEmail): bool
    {
        $stmt = $this->pdo->prepare(
            'SELECT 1 FROM shares WHERE file_id = :file_id AND recipient_email = :email LIMIT 1'
        );
        $stmt->execute(['file_id' => $fileId, 'email' => strtolower(trim($recipientEmail))]);

        return (bool) $stmt->fetchColumn();
    }
}
