<?php

declare(strict_types=1);

use App\Core\Request;
use App\Core\Router;

$boot = require dirname(__DIR__) . '/src/bootstrap.php';

$router = new Router($boot['pdo'], $boot['config']);
$routes = require dirname(__DIR__) . '/config/routes.php';

foreach ($routes as [$method, $path, $handler]) {
    $router->add($method, $path, $handler);
}

$request = Request::capture();
$router->dispatch($request);
