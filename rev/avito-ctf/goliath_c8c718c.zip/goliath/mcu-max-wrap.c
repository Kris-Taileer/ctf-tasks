#include "mcu-max.h"

static char fen_buf[256] = FLAG;
static char move_buf[8];

__attribute__((export_name("fen_buffer")))
char *fen_buffer(void)
{
    return fen_buf;
}

static char *format_square(char *p, mcumax_square sq)
{
    *p++ = 'a' + (sq & 7);
    *p++ = '0' + (8 - (sq >> 4));
    return p;
}

__attribute__((export_name("best_move")))
char *best_move(void)
{
    mcumax_set_fen_position(fen_buf);
    mcumax_move move = mcumax_search_best_move(1000000, 30);

    if (move.from == MCUMAX_SQUARE_INVALID || move.to == MCUMAX_SQUARE_INVALID)
        return 0;

    char *p = move_buf;
    p = format_square(p, move.from);
    p = format_square(p, move.to);
    *p = '\0';
    return move_buf;
}
