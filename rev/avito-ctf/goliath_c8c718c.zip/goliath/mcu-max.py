#!/usr/bin/env python3
import os
import sys

from fastapi import APIRouter, FastAPI, HTTPException, UploadFile
from fastapi.staticfiles import StaticFiles
from wasmtime import Config, Engine, Instance, Module, Store, WasmtimeError


class Player:
    def __init__(self, engine, module):
        self.__engine = engine
        self.__module = module
        self.__store = Store(engine)
        self.__instance = Instance(self.__store, module, imports=[])
        self.__exports = self.__instance.exports(self.__store)
        self.__memory = self.__exports["memory"].data_ptr(self.__store)
        self.__fen_buffer = self.__exports["fen_buffer"]
        self.__best_move = self.__exports["best_move"]

    def best_move(self, fen: str) -> str:
        data = fen.encode("latin-1") + b"\x00"
        if len(data) > 256:
            raise HTTPException(
                status_code=400,
                detail="FEN string too long for engine buffer (max 255)",
            )
        fen_buffer = self.__fen_buffer(self.__store)
        for i, b in enumerate(data):
            self.__memory[fen_buffer + i] = b
        ptr = self.__best_move(self.__store)
        if ptr == 0:
            raise HTTPException(
                status_code=422, detail="no legal move (checkmate/stalemate)"
            )
        move = bytearray()
        while b := self.__memory[ptr + len(move)]:
            move.append(b)
        return move.decode("latin-1", errors="replace")


WASM_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcu-max.wasm")
ENGINE = Engine()
BEE_PLAYER = Player(ENGINE, Module.from_file(ENGINE, WASM_PATH))
BADGER_PLAYER = None
APP = FastAPI(title="mcu-max")
API = APIRouter(prefix="/api")


@API.post("/upload")
async def upload(file: UploadFile):
    wasm_bytes = await file.read()
    try:
        module = Module(ENGINE, wasm_bytes)
    except WasmtimeError as exc:
        raise HTTPException(status_code=400, detail=f"invalid WASM module: {exc}")
    player = Player(ENGINE, module)
    global BADGER_PLAYER
    BADGER_PLAYER = player
    return {"status": "ok", "bytes": len(wasm_bytes)}


@API.get("/best-move")
def get_best_move(fen: str):
    fields = fen.split()
    active = fields[1] if len(fields) > 1 else ""
    if active == "w":
        player = BEE_PLAYER
    elif active == "b":
        player = BADGER_PLAYER
    else:
        raise HTTPException(
            status_code=400,
            detail="FEN missing active color (field 2 must be 'w' or 'b')",
        )
    if player is None:
        raise HTTPException(
            status_code=409,
            detail=f"󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅗󠅟󠅗󠅑󠅝󠅒󠅙󠅤󠄝󠄩󠅪󠅒󠄢󠅛󠅚󠅚󠄦󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟no engine loaded for {'White' if player == 0 else 'Black'}",
        )
    return {"best_move": player.best_move(fen)}


APP.include_router(API)
APP.mount(
    "/",
    StaticFiles(
        directory=os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "web", "dist"
        ),
        html=True,
    ),
    name="web",
)


if __name__ == "__main__":
    import uvicorn

    if len(sys.argv) > 1:
        host, port = sys.argv[1].split(":")
        port = int(port)
    else:
        host, port = "127.0.0.1", 8000
    uvicorn.run(APP, host=host, port=port)
