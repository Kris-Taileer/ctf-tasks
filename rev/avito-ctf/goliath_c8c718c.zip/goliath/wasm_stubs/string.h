#ifndef WASM_STUBS_STRING_H
#define WASM_STUBS_STRING_H

static inline void *memset(void *dst, int value, unsigned long count)
{
    unsigned char *d = (unsigned char *)dst;
    while (count--)
        *d++ = (unsigned char)value;
    return dst;
}

static inline void *memcpy(void *dst, const void *src, unsigned long count)
{
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    while (count--)
        *d++ = *s++;
    return dst;
}

#endif
