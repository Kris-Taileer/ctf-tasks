package ru.avito.iot.hivehub.web;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import ru.avito.iot.hivehub.model.Device;
import ru.avito.iot.hivehub.model.UserAccount;
import ru.avito.iot.hivehub.service.DeviceRegistry;
import ru.avito.iot.hivehub.service.DeviceStatusStream;
import ru.avito.iot.hivehub.service.FlagResolver;
import ru.avito.iot.hivehub.service.MaintenanceBot;
import ru.avito.iot.hivehub.service.SessionService;

import java.util.List;
import java.util.Map;

@RestController
public class DeviceController {
    private final DeviceRegistry devices;
    private final SessionService sessions;
    private final MaintenanceBot maintenanceBot;
    private final FlagResolver flags;
    private final DeviceStatusStream statusStream;

    public DeviceController(DeviceRegistry devices, SessionService sessions, MaintenanceBot maintenanceBot, FlagResolver flags, DeviceStatusStream statusStream) {
        this.devices = devices;
        this.sessions = sessions;
        this.maintenanceBot = maintenanceBot;
        this.flags = flags;
        this.statusStream = statusStream;
    }

    @GetMapping("/api/devices")
    public List<Device> list(HttpServletRequest request) {
        sessions.require(request);
        return devices.list();
    }

    @GetMapping(value = "/api/device-stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(HttpServletRequest request) {
        sessions.require(request);
        return statusStream.subscribe();
    }

    @PostMapping("/api/devices/{id}/power")
    public Device setPower(@PathVariable("id") String id, @RequestParam("enabled") boolean enabled, HttpServletRequest request) {
        UserAccount actor = sessions.require(request);
        Device updated = devices.setEnabled(id, enabled, actor);
        if ("hive-speakers".equals(id) && !enabled) {
            maintenanceBot.restoreSpeakers();
        }
        return updated;
    }

    @PostMapping("/api/devices/{id}/controls/{name}")
    public Device setControl(
            @PathVariable("id") String id,
            @PathVariable("name") String name,
            @RequestParam("value") double value,
            HttpServletRequest request
    ) {
        UserAccount actor = sessions.require(request);
        return devices.setControl(id, name, value, actor);
    }

    @PostMapping("/api/devices/landing-gate/open")
    public Map<String, Object> openLandingGate(HttpServletRequest request) {
        UserAccount actor = sessions.require(request);
        return devices.openLandingGate(actor, flags.resolveFlag(request));
    }
}
