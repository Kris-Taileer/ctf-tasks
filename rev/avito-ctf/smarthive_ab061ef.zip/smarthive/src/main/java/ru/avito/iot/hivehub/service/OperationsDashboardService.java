package ru.avito.iot.hivehub.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import ru.avito.iot.hivehub.model.Device;
import ru.avito.iot.hivehub.model.UserAccount;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class OperationsDashboardService {
    private final DeviceRegistry devices;
    private final JdbcTemplate jdbc;
    private final EventLogService events;

    public OperationsDashboardService(DeviceRegistry devices, JdbcTemplate jdbc, EventLogService events) {
        this.devices = devices;
        this.jdbc = jdbc;
        this.events = events;
    }

    public DashboardSnapshot snapshot(UserAccount account) {
        List<Device> current = devices.list();
        long enabled = current.stream().filter(Device::enabled).count();
        boolean speakersEnabled = devices.get("hive-speakers").enabled();
        boolean gateEnabled = devices.get("landing-gate").enabled();
        List<ZoneReading> zones = zones();
        String nectarHumidity = zones.stream()
                .filter(zone -> "Ряд рамок B".equals(zone.zone()))
                .map(ZoneReading::humidity)
                .findFirst()
                .orElse("n/a");
        String broodTemperature = zones.stream()
                .filter(zone -> "Сота питомника".equals(zone.zone()))
                .map(ZoneReading::temperature)
                .findFirst()
                .orElse("n/a");

        List<DevicePanel> devicePanels = current.stream()
                .map(device -> panel(device, account))
                .toList();

        return new DashboardSnapshot(
                "HIVE-T19",
                "Северный улей",
                Instant.now(),
                new Summary(
                        current.size(),
                        (int) enabled,
                        speakersEnabled ? "успокаивающий цикл активен" : "звук отключен вручную",
                        gateEnabled ? "автораспознавание" : "ручное управление",
                        speakersEnabled ? 1 : 2,
                        nectarHumidity,
                        broodTemperature,
                        "11 ppm",
                        "стабильно"
                ),
                zones,
                devicePanels,
                incidents(),
                events.latest(10),
                automations(),
                topology()
        );
    }

    private List<ZoneReading> zones() {
        return jdbc.query("""
                        SELECT zone, subsystem, temperature, humidity, throughput, state
                        FROM zone_readings
                        ORDER BY zone
                        """,
                (rs, rowNum) -> new ZoneReading(
                        rs.getString("zone"),
                        rs.getString("subsystem"),
                        format(rs.getDouble("temperature"), " C"),
                        format(rs.getDouble("humidity"), "%"),
                        rs.getString("throughput"),
                        rs.getString("state")
                ));
    }

    private List<Incident> incidents() {
        return jdbc.query("""
                        SELECT id, severity, title, device_id, detail, state
                        FROM incidents
                        ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END, id
                        """,
                (rs, rowNum) -> new Incident(
                        rs.getString("id"),
                        rs.getString("severity"),
                        rs.getString("title"),
                        rs.getString("device_id"),
                        rs.getString("detail"),
                        rs.getString("state")
                ));
    }

    private List<AutomationRule> automations() {
        Instant now = Instant.now();
        return jdbc.query("""
                        SELECT id, title, trigger_text, action_text, enabled, last_run_at
                        FROM automation_rules
                        ORDER BY id
                        """,
                (rs, rowNum) -> new AutomationRule(
                        rs.getString("id"),
                        rs.getString("title"),
                        rs.getString("trigger_text"),
                        rs.getString("action_text"),
                        rs.getBoolean("enabled"),
                        lastRunLabel(rs.getString("id"), rs.getObject("last_run_at", Instant.class), rs.getBoolean("enabled"), now)
                ));
    }

    private static final Map<String, Long> SENSOR_RULE_PERIOD_SECONDS = Map.of(
            "gate-bee-recognition", 47L,
            "brood-thermal-a", 73L,
            "nectar-drainage-b", 380L
    );

    private String lastRunLabel(String id, Instant lastRunAt, boolean enabled, Instant now) {
        Instant effective = lastRunAt;
        Long period = SENSOR_RULE_PERIOD_SECONDS.get(id);
        if (period != null && enabled) {
            long phase = Math.floorMod(id.hashCode(), period);
            Instant synthetic = Instant.ofEpochSecond(now.getEpochSecond() - Math.floorMod(now.getEpochSecond() - phase, period));
            if (effective == null || synthetic.isAfter(effective)) {
                effective = synthetic;
            }
        }
        if (effective == null) {
            return "ожидает";
        }
        long seconds = Math.max(0, java.time.Duration.between(effective, now).getSeconds());
        if (seconds < 10) {
            return "только что";
        }
        if (seconds < 60) {
            return seconds + " с назад";
        }
        if (seconds < 3600) {
            return (seconds / 60) + " мин назад";
        }
        if (seconds < 86400) {
            return (seconds / 3600) + " ч назад";
        }
        return (seconds / 86400) + " д назад";
    }

    private List<RouteHop> topology() {
        return jdbc.query("""
                        SELECT service, state, responsibility, latency
                        FROM route_hops
                        ORDER BY sort_order
                        """,
                (rs, rowNum) -> new RouteHop(
                        rs.getString("service"),
                        rs.getString("state"),
                        rs.getString("responsibility"),
                        rs.getString("latency")
                ));
    }

    private DevicePanel panel(Device device, UserAccount account) {
        boolean writable = device.writableBy().stream().anyMatch(account::hasRole);
        DeviceRegistry.DeviceDetails details = devices.details(device.id());
        return new DevicePanel(
                device.id(), device.title(), device.location(), device.kind().name(), device.online(), device.enabled(), writable,
                details.state(), details.firmware(), details.signal(), details.load(), devices.metrics(device.id())
        );
    }

    private String format(double value, String suffix) {
        return String.format(java.util.Locale.ROOT, "%.1f%s", value, suffix);
    }

    public record DashboardSnapshot(
            String hiveId,
            String siteName,
            Instant generatedAt,
            Summary summary,
            List<ZoneReading> zones,
            List<DevicePanel> devices,
            List<Incident> incidents,
            List<EventLogService.OperationEvent> events,
            List<AutomationRule> automations,
            List<RouteHop> topology
    ) {
    }

    public record Summary(
            int devicesTotal,
            int devicesEnabled,
            String acousticState,
            String landingGateState,
            int activeIncidents,
            String nectarHumidity,
            String broodTemperature,
            String co2Level,
            String colonyState
    ) {
    }

    public record ZoneReading(
            String zone,
            String subsystem,
            String temperature,
            String humidity,
            String throughput,
            String state
    ) {
    }

    public record DevicePanel(
            String id,
            String title,
            String location,
            String kind,
            boolean online,
            boolean enabled,
            boolean writable,
            String state,
            String firmware,
            String signal,
            String load,
            Map<String, String> metrics
    ) {
    }

    public record Incident(
            String id,
            String severity,
            String title,
            String deviceId,
            String detail,
            String state
    ) {
    }

    public record AutomationRule(
            String id,
            String title,
            String trigger,
            String action,
            boolean enabled,
            String lastRun
    ) {
    }

    public record RouteHop(
            String service,
            String state,
            String responsibility,
            String latency
    ) {
    }
}
