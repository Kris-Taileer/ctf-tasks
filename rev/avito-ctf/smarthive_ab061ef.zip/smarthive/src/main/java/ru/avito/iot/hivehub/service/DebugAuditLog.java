package ru.avito.iot.hivehub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.avito.iot.hivehub.config.HiveProperties;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Clock;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.regex.Pattern;
import java.util.concurrent.locks.ReentrantLock;

@Service
public class DebugAuditLog {
    private static final Pattern SENSITIVE_QUERY_PARAM = Pattern.compile("([?&]password=)[^&\\s]*");
    private static final long MIN_COMPACTION_SIZE_BYTES = 1024 * 1024;
    private static final int TAIL_READ_BLOCK_BYTES = 64 * 1024;

    private final Path path;
    private final Clock clock;
    private final long maxBytes;
    private final int retainedLines;
    private final ReentrantLock compactionLock = new ReentrantLock();

    @Autowired
    public DebugAuditLog(HiveProperties properties) throws IOException {
        this(properties, Clock.systemUTC());
    }

    DebugAuditLog(HiveProperties properties, Clock clock) throws IOException {
        this.path = properties.logPath();
        this.clock = clock;
        this.maxBytes = Math.max(MIN_COMPACTION_SIZE_BYTES, properties.logMaxBytes());
        this.retainedLines = Math.max(1, properties.logRetainedLines());
        Path parent = path.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        if (!Files.exists(path)) {
            Files.createFile(path);
        }
    }

    public void append(String service, String message) {
        String normalized = message.replace('\r', ' ').replace('\n', ' ');
        String line = DateTimeFormatter.ISO_INSTANT.format(clock.instant()) + " " + service + " " + normalized + "\n";
        compactIfNeeded();
        try {
            Files.writeString(path, line, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new IllegalStateException("debug log write failed", e);
        }
    }

    public List<String> readMasked(int maxLines) {
        if (!Files.exists(path)) {
            return List.of();
        }
        compactionLock.lock();
        try {
            Deque<String> tail = new ArrayDeque<>();
            int bounded = Math.max(1, maxLines);
            readTailFromCurrent(bounded, tail);
            List<String> result = new ArrayList<>();
            for (String line : tail) {
                result.add(redactSensitiveValues(line));
            }
            return result;
        } catch (IOException e) {
            throw new IllegalStateException("debug log read failed", e);
        } finally {
            compactionLock.unlock();
        }
    }

    public void clear() {
        compactionLock.lock();
        try {
            Files.writeString(path, "", StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            throw new IllegalStateException("debug log clear failed", e);
        } finally {
            compactionLock.unlock();
        }
    }

    private String redactSensitiveValues(String line) {
        return SENSITIVE_QUERY_PARAM.matcher(line).replaceFirst("$1********");
    }

    private void compactIfNeeded() {
        if (!Files.exists(path)) {
            return;
        }
        try {
            if (Files.size(path) < maxBytes || !compactionLock.tryLock()) {
                return;
            }
        } catch (IOException e) {
            throw new IllegalStateException("debug log compaction check failed", e);
        }
        try {
            if (Files.exists(path) && Files.size(path) >= maxBytes) {
                compactToTail();
            }
        } catch (IOException e) {
            throw new IllegalStateException("debug log compaction failed", e);
        } finally {
            compactionLock.unlock();
        }
    }

    private void compactToTail() throws IOException {
        Deque<String> tail = new ArrayDeque<>();
        readTailFromCurrent(retainedLines, tail);
        Path parent = path.getParent();
        Path temp = Files.createTempFile(parent == null ? Path.of(".") : parent, path.getFileName().toString(), ".tmp");
        try {
            try (BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (String line : tail) {
                    writer.write(line);
                    writer.newLine();
                }
            }
            Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temp);
        }
    }

    private void readTailFromCurrent(int maxLines, Deque<String> tail) throws IOException {
        if (!Files.exists(path)) {
            return;
        }
        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.READ)) {
            long size = channel.size();
            if (size == 0) {
                return;
            }
            channel.position(tailStart(channel, size, maxLines));
            try (BufferedReader reader = new BufferedReader(Channels.newReader(channel, StandardCharsets.UTF_8.newDecoder(), -1))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    addTailLine(tail, maxLines, line);
                }
            }
        }
    }

    private long tailStart(FileChannel channel, long size, int maxLines) throws IOException {
        int separatorsToFind = maxLines + (byteAt(channel, size - 1) == '\n' ? 1 : 0);
        int separatorsFound = 0;
        long position = size;
        ByteBuffer buffer = ByteBuffer.allocate((int) Math.min(TAIL_READ_BLOCK_BYTES, size));

        while (position > 0) {
            int toRead = (int) Math.min(buffer.capacity(), position);
            position -= toRead;
            buffer.clear();
            buffer.limit(toRead);
            readFully(channel, buffer, position);

            byte[] bytes = buffer.array();
            for (int i = toRead - 1; i >= 0; i--) {
                if (bytes[i] == '\n') {
                    separatorsFound++;
                    if (separatorsFound == separatorsToFind) {
                        return position + i + 1;
                    }
                }
            }
        }

        return 0;
    }

    private byte byteAt(FileChannel channel, long position) throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(1);
        readFully(channel, buffer, position);
        return buffer.array()[0];
    }

    private void readFully(FileChannel channel, ByteBuffer buffer, long position) throws IOException {
        while (buffer.hasRemaining()) {
            int read = channel.read(buffer, position + buffer.position());
            if (read < 0) {
                throw new EOFException("debug log ended while reading tail");
            }
            if (read == 0) {
                throw new IOException("debug log tail read stalled");
            }
        }
    }

    private void addTailLine(Deque<String> tail, int maxLines, String line) {
        tail.addLast(line);
        while (tail.size() > maxLines) {
            tail.removeFirst();
        }
    }
}
