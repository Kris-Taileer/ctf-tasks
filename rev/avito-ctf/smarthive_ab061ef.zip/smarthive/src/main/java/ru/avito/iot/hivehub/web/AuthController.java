package ru.avito.iot.hivehub.web;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.avito.iot.hivehub.model.UserAccount;
import ru.avito.iot.hivehub.service.AccountService;
import ru.avito.iot.hivehub.service.EventLogService;
import ru.avito.iot.hivehub.service.SessionService;

import java.util.Map;

@RestController
public class AuthController {
    private final AccountService accounts;
    private final SessionService sessions;
    private final EventLogService events;

    public AuthController(AccountService accounts, SessionService sessions, EventLogService events) {
        this.accounts = accounts;
        this.sessions = sessions;
        this.events = events;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @RequestParam("username") @NotBlank String username,
            @RequestParam("password") @NotBlank String password,
            HttpServletResponse response
    ) {
        return accounts.authenticate(username, password)
                .map(account -> {
                    events.record("auth", "info", account.username(), "session", "Сессия оператора открыта", account.displayName());
                    return loginResponse(response, account);
                })
                .orElseGet(() -> {
                    events.record("auth", "warning", username, "session", "Попытка входа отклонена ❌󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅪󠅑󠅜󠅕󠅤󠅑󠅩󠄝󠄥󠅠󠅩󠅤󠅖󠅥󠅑󠅑󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟", "В шлюз авторизации переданы неверные учетные данные.");
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(Map.of("ok", false, "message", "неверное имя пользователя или пароль"));
                });
    }

    @GetMapping("/api/me")
    public Map<String, Object> me(HttpServletRequest request) {
        return accountResponse(sessions.require(request));
    }

    @PostMapping("/api/profile")
    public Map<String, Object> updateProfile(
            @RequestParam("displayName") @NotBlank String displayName,
            HttpServletRequest request
    ) {
        UserAccount account = sessions.require(request);
        UserAccount updated = accounts.updateDisplayName(account, displayName);
        events.record("profile", "info", account.username(), "profile", "Профиль обновлен", "Отображаемое имя оператора изменено.");
        return accountResponse(updated);
    }

    @PostMapping("/api/profile/password")
    public Map<String, Object> updatePassword(
            @RequestParam("currentPassword") @NotBlank String currentPassword,
            @RequestParam("newPassword") @NotBlank String newPassword,
            HttpServletRequest request
    ) {
        UserAccount account = sessions.require(request);
        UserAccount updated = accounts.changePassword(account, currentPassword, newPassword);
        events.record("profile", "info", account.username(), "credentials", "Пароль обновлен", "Пароль оператора изменен.");
        return accountResponse(updated);
    }

    @DeleteMapping("/api/session")
    public Map<String, Object> logout(HttpServletRequest request, HttpServletResponse response) {
        sessions.readCookie(request).ifPresent(sessions::destroy);
        Cookie cookie = new Cookie(SessionService.COOKIE_NAME, "");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
        return Map.of("ok", true);
    }

    private ResponseEntity<Map<String, Object>> loginResponse(HttpServletResponse response, UserAccount account) {
        Cookie cookie = new Cookie(SessionService.COOKIE_NAME, sessions.create(account));
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        cookie.setMaxAge(3600);
        response.addCookie(cookie);
        return ResponseEntity.ok(accountResponse(account));
    }

    private Map<String, Object> accountResponse(UserAccount account) {
        return Map.of(
                "ok", true,
                "username", account.username(),
                "displayName", account.displayName(),
                "roles", account.roles()
        );
    }
}
