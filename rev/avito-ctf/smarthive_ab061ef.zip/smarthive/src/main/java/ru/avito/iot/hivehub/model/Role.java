package ru.avito.iot.hivehub.model;

public enum Role {
    AUDIO_OPERATOR,
    ENGINEER
}
