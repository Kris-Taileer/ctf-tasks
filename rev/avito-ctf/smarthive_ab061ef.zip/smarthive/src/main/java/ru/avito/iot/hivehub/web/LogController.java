package ru.avito.iot.hivehub.web;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.avito.iot.hivehub.service.DebugAuditLog;
import ru.avito.iot.hivehub.service.SessionService;

@RestController
public class LogController {
    private final DebugAuditLog debugLog;
    private final SessionService sessions;

    public LogController(DebugAuditLog debugLog, SessionService sessions) {
        this.debugLog = debugLog;
        this.sessions = sessions;
    }

    @GetMapping(value = "/debug/logs", produces = MediaType.TEXT_PLAIN_VALUE)
    public String logs(@RequestParam(name = "lines", defaultValue = "200") int lines, HttpServletRequest request) {
        sessions.require(request);
        int bounded = Math.max(1, Math.min(lines, 1000));
        return String.join("\n", debugLog.readMasked(bounded)) + "\n";
    }

    @PostMapping("/debug/logs/clear")
    public void clear(HttpServletRequest request) {
        sessions.require(request);
        debugLog.clear();
    }
}
