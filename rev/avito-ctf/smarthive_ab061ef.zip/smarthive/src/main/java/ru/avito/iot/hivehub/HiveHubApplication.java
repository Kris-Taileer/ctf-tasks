package ru.avito.iot.hivehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class HiveHubApplication {
    public static void main(String[] args) {
        SpringApplication.run(HiveHubApplication.class, args);
    }
}
