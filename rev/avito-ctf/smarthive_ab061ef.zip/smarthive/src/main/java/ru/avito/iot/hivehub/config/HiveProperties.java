package ru.avito.iot.hivehub.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.nio.file.Path;

@ConfigurationProperties(prefix = "hive")
public record HiveProperties(
        Path logPath,
        long logMaxBytes,
        int logRetainedLines,
        String lowUser,
        String lowPassword,
        String engineerUser,
        String engineerPassword,
        String hubBaseUrl,
        long botDelayMs
) {
}
