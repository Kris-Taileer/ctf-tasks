package ru.avito.iot.hivehub.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import ru.avito.iot.hivehub.bootstrap.DatabaseSeeder;
import ru.avito.iot.hivehub.model.Device;
import ru.avito.iot.hivehub.model.DeviceKind;
import ru.avito.iot.hivehub.model.Role;
import ru.avito.iot.hivehub.model.UserAccount;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class DeviceRegistry {
    private final JdbcTemplate jdbc;
    private final EventLogService events;
    private final DeviceStatusStream statusStream;

    public DeviceRegistry(JdbcTemplate jdbc, DatabaseSeeder databaseSeeder, EventLogService events, DeviceStatusStream statusStream) {
        this.jdbc = jdbc;
        this.events = events;
        this.statusStream = statusStream;
    }

    public List<Device> list() {
        return jdbc.query("""
                        SELECT id, title, location, kind, online, enabled, updated_at
                        FROM devices
                        """,
                (rs, rowNum) -> new Device(
                        rs.getString("id"),
                        rs.getString("title"),
                        rs.getString("location"),
                        DeviceKind.valueOf(rs.getString("kind")),
                        writableBy(rs.getString("id")),
                        rs.getBoolean("online"),
                        rs.getBoolean("enabled"),
                        rs.getObject("updated_at", Instant.class)
                ))
                .stream()
                .sorted(Comparator.comparing(Device::id))
                .toList();
    }

    public Device get(String id) {
        return jdbc.query("""
                        SELECT id, title, location, kind, online, enabled, updated_at
                        FROM devices
                        WHERE id = ?
                        """,
                (rs, rowNum) -> new Device(
                        rs.getString("id"),
                        rs.getString("title"),
                        rs.getString("location"),
                        DeviceKind.valueOf(rs.getString("kind")),
                        writableBy(rs.getString("id")),
                        rs.getBoolean("online"),
                        rs.getBoolean("enabled"),
                        rs.getObject("updated_at", Instant.class)
                ),
                id
        ).stream().findFirst().orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "неизвестное устройство"));
    }

    public Device setEnabled(String id, boolean enabled, UserAccount actor) {
        Device current = get(id);
        ensureWritable(current, actor);
        updateEnabled(id, enabled, actor.username());
        return get(id);
    }

    public Map<String, Object> openLandingGate(UserAccount actor, String flag) {
        Device current = get("landing-gate");
        ensureWritable(current, actor);
        updateEnabled(current.id(), true, actor.username());
        Device updated = get(current.id());
        events.record("device", "info", actor.username(), current.id(), "Ручное открытие летковых ворот принято 🔓󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅪󠅑󠅜󠅕󠅤󠅑󠅩󠄝󠄥󠅠󠅩󠅤󠅖󠅥󠅑󠅑󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟", "Сервисный токен выдан авторизованной сессии инженера.");
        return Map.of(
                "device", updated,
                "message", "Ручное открытие летковых ворот принято",
                "serviceToken", flag
        );
    }

    public Device setControl(String id, String name, double value, UserAccount actor) {
        Device current = get(id);
        ensureWritable(current, actor);
        if (!current.enabled()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "устройство должно быть включено перед изменением настроек");
        }
        DeviceControl control = DeviceControl.find(id, name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "неизвестная настройка устройства"));
        if (value < control.min() || value > control.max()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    control.label() + " должна быть между " + control.format(control.min()) + " и " + control.format(control.max()));
        }

        String formattedValue = control.format(value);
        jdbc.update("""
                MERGE INTO device_metrics KEY(device_id, metric_name)
                VALUES (?, ?, ?)
                """, id, name, formattedValue);
        applyControlState(id, name, formattedValue);
        events.record("device", "info", actor.username(), id,
                "Настройка устройства изменена", control.label() + ": " + formattedValue);
        Device updated = get(id);
        statusStream.publish(updated, actor.username());
        return updated;
    }

    private void updateEnabled(String id, boolean enabled, String actor) {
        String state = enabled ? enabledState(id) : disabledState(id);
        jdbc.update("""
                UPDATE devices
                SET enabled = ?, state = ?, updated_at = ?
                WHERE id = ?
                """, enabled, state, Instant.now(), id);
        if ("hive-speakers".equals(id)) {
            jdbc.update("""
                    UPDATE device_metrics
                    SET metric_value = ?
                    WHERE device_id = 'hive-speakers' AND metric_name = 'track'
                    """, enabled ? "forager-bed-03" : "нет");
            jdbc.update("""
                    UPDATE device_metrics
                    SET metric_value = ?
                    WHERE device_id = 'hive-speakers' AND metric_name = 'health'
                    """, enabled ? "штатно" : "восстановление");
            String volume = enabled ? metricValue("hive-speakers", "volume", "40%") : "0%";
            jdbc.update("UPDATE zone_readings SET throughput = ?, state = ?, updated_at = ? WHERE zone = 'Главная камера'",
                    volume, enabled ? "active" : "silent", Instant.now());
            if (enabled) {
                jdbc.update("DELETE FROM incidents WHERE id = 'audio-muted'");
                jdbc.update("UPDATE route_hops SET state = 'idle', latency = 'резерв' WHERE service = 'maintenance-console'");
            } else {
                jdbc.update("UPDATE automation_rules SET last_run_at = ? WHERE id = 'acoustic-monitor'", Instant.now());
                jdbc.update("""
                        MERGE INTO incidents KEY(id)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        "audio-muted", "critical", "Акустическая подсистема приглушена", "hive-speakers",
                        "Цикл комфорта выключен; ожидается подтверждение дежурного инженера.", "open", Instant.now());
                jdbc.update("UPDATE route_hops SET state = 'active', latency = 'восстановление в очереди' WHERE service = 'maintenance-console'");
            }
        }
        events.record("device", enabled ? "info" : "warning", actor, id,
                "Состояние питания устройства изменено", "включено: " + (enabled ? "да" : "нет") + ", состояние: " + state);
        statusStream.publish(get(id), actor);
    }

    private void applyControlState(String id, String name, String formattedValue) {
        switch (id + ":" + name) {
            case "hive-speakers:volume" -> {
                jdbc.update("UPDATE devices SET load_value = ?, state = ?, updated_at = ? WHERE id = ?",
                        formattedValue, "успокаивающий цикл", Instant.now(), id);
                jdbc.update("UPDATE zone_readings SET throughput = ?, state = ?, updated_at = ? WHERE zone = 'Главная камера'",
                        formattedValue, "active", Instant.now());
            }
            case "brood-incubator-a:heater" -> {
                jdbc.update("UPDATE devices SET load_value = ?, state = ?, updated_at = ? WHERE id = ?",
                        formattedValue, "нагрев " + formattedValue, Instant.now(), id);
                jdbc.update("UPDATE automation_rules SET last_run_at = ? WHERE id = 'brood-thermal-a'", Instant.now());
            }
            case "nectar-drainage:flow" -> {
                jdbc.update("UPDATE devices SET load_value = ?, state = ?, updated_at = ? WHERE id = ?",
                        formattedValue, "поток " + formattedValue, Instant.now(), id);
                jdbc.update("UPDATE zone_readings SET throughput = ?, state = ?, updated_at = ? WHERE zone = 'Ряд рамок B'",
                        formattedValue, numericValue(formattedValue) > 0.0 ? "draining" : "closed", Instant.now());
                jdbc.update("UPDATE automation_rules SET last_run_at = ? WHERE id = 'nectar-drainage-b'", Instant.now());
            }
            case "landing-gate:confidence" -> {
                jdbc.update("UPDATE devices SET load_value = ?, state = ?, updated_at = ? WHERE id = ?",
                        formattedValue, "порог уверенности " + formattedValue, Instant.now(), id);
                jdbc.update("UPDATE zone_readings SET throughput = ?, state = ?, updated_at = ? WHERE zone = 'Внешняя стенка'",
                        formattedValue, "clear", Instant.now());
                jdbc.update("UPDATE automation_rules SET trigger_text = ?, last_run_at = ? WHERE id = 'gate-bee-recognition'",
                        "уверенность камеры > " + formattedValue, Instant.now());
            }
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND, "неизвестная настройка устройства");
        }
    }

    public Map<String, String> metrics(String deviceId) {
        return jdbc.query("""
                        SELECT metric_name, metric_value
                        FROM device_metrics
                        WHERE device_id = ?
                        ORDER BY metric_name
                        """,
                rs -> {
                    Map<String, String> values = new java.util.LinkedHashMap<>();
                    while (rs.next()) {
                        values.put(rs.getString("metric_name"), rs.getString("metric_value"));
                    }
                    return values;
                },
                deviceId);
    }

    public DeviceDetails details(String deviceId) {
        return jdbc.query("""
                        SELECT firmware, signal, load_value, state
                        FROM devices
                        WHERE id = ?
                        """,
                (rs, rowNum) -> new DeviceDetails(
                        rs.getString("firmware"),
                        rs.getString("signal"),
                        rs.getString("load_value"),
                        rs.getString("state")
                ),
                deviceId
        ).stream().findFirst().orElse(new DeviceDetails("неизвестно", "н/д", "н/д", "offline"));
    }

    private String metricValue(String deviceId, String metricName, String fallback) {
        List<String> values = jdbc.queryForList("""
                SELECT metric_value
                FROM device_metrics
                WHERE device_id = ? AND metric_name = ?
                """, String.class, deviceId, metricName);
        return values.isEmpty() ? fallback : values.getFirst();
    }

    private double numericValue(String value) {
        try {
            return Double.parseDouble(value.replaceAll("[^0-9.\\-]", ""));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private String enabledState(String id) {
        return switch (id) {
            case "landing-gate" -> "цикл распознавания";
            case "nectar-drainage" -> "цикл готов";
            case "brood-incubator-a" -> "тепловое удержание";
            case "hive-speakers" -> "успокаивающий цикл";
            default -> "enabled";
        };
    }

    private String disabledState(String id) {
        return switch (id) {
            case "landing-gate" -> "ручное удержание";
            case "nectar-drainage" -> "клапаны закрыты";
            case "brood-incubator-a" -> "нагрев выключен";
            case "hive-speakers" -> "приглушено";
            default -> "disabled";
        };
    }

    private Set<Role> writableBy(String deviceId) {
        return jdbc.queryForList("SELECT role FROM device_permissions WHERE device_id = ?", String.class, deviceId)
                .stream()
                .map(Role::valueOf)
                .collect(Collectors.toSet());
    }

    private void ensureWritable(Device device, UserAccount actor) {
        boolean allowed = device.writableBy().stream().anyMatch(actor::hasRole);
        if (!allowed) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "недостаточно прав для управления устройством");
        }
    }

    public record DeviceDetails(String firmware, String signal, String load, String state) {
    }

    private record DeviceControl(String deviceId, String name, String label, double min, double max, String suffix) {
        static Optional<DeviceControl> find(String deviceId, String name) {
            return CONTROLS.stream()
                    .filter(control -> control.deviceId().equals(deviceId) && control.name().equals(name))
                    .findFirst();
        }

        String format(double value) {
            if (Math.rint(value) == value) {
                return String.format(Locale.ROOT, "%.0f%s", value, suffix);
            }
            return String.format(Locale.ROOT, "%.1f%s", value, suffix);
        }
    }

    private static final List<DeviceControl> CONTROLS = List.of(
            new DeviceControl("hive-speakers", "volume", "Громкость", 10.0, 100.0, "%"),
            new DeviceControl("brood-incubator-a", "heater", "Нагрев", 0.0, 100.0, "%"),
            new DeviceControl("nectar-drainage", "flow", "Поток дренажа", 0.0, 10.0, " мл/мин"),
            new DeviceControl("landing-gate", "confidence", "Уровень уверенности", 50.0, 99.0, "%")
    );
}
