package ru.avito.iot.hivehub.service;

import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.avito.iot.hivehub.config.HiveProperties;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
public class MaintenanceBot {
    private static final Logger log = LoggerFactory.getLogger(MaintenanceBot.class);

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .build();
    private final EventLogService events;
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "hive-maintenance-bot");
        thread.setDaemon(true);
        return thread;
    });
    private final String engineerUsername;
    private final String engineerPassword;
    private final String hubBaseUrl;
    private final long botDelayMs;

    public MaintenanceBot(HiveProperties properties, EventLogService events) {
        this.events = events;
        this.engineerUsername = properties.engineerUser();
        this.engineerPassword = properties.engineerPassword();
        this.hubBaseUrl = stripTrailingSlash(properties.hubBaseUrl());
        this.botDelayMs = properties.botDelayMs();
    }

    public void restoreSpeakers() {
        executor.schedule(this::restoreDeviceState, botDelayMs, TimeUnit.MILLISECONDS);
    }

    private void restoreDeviceState() {
        try {
            events.record("automation", "warning", "acoustic-monitor", "hive-speakers", "Запрошено восстановление обслуживания", "Динамики были выключены оператором.");
            String sessionCookie = loginAsEngineer();
            restoreDevice(sessionCookie);
            events.record("automation", "info", engineerUsername, "hive-speakers", "Восстановление обслуживания завершено", "Консоль дежурного инженера восстановила акустическую подсистему.");
        } catch (IOException e) {
            events.record("automation", "critical", "acoustic-monitor", "hive-speakers", "Восстановление обслуживания не выполнено", e.getMessage());
            log.warn("maintenance console request failed", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            events.record("automation", "critical", "acoustic-monitor", "hive-speakers", "Восстановление обслуживания прервано", "Задача восстановления была прервана.");
            log.warn("maintenance console request interrupted", e);
        }
    }

    private String loginAsEngineer() throws IOException, InterruptedException {
        String body = "username=" + enc(engineerUsername)
                + "&password=" + enc(engineerPassword)
                + "&remember=true&client=maintenance-console";
        HttpRequest request = HttpRequest.newBuilder(uri("/login"))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IOException("вход инженера завершился статусом " + response.statusCode());
        }
        return response.headers().firstValue("Set-Cookie")
                .map(value -> value.split(";", 2)[0])
                .orElseThrow(() -> new IOException("вход инженера не вернул cookie сессии"));
    }

    private void restoreDevice(String sessionCookie) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(uri("/api/devices/hive-speakers/power?enabled=true"))
                .timeout(Duration.ofSeconds(10))
                .header("Cookie", sessionCookie)
                .POST(HttpRequest.BodyPublishers.noBody())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IOException("восстановление динамиков завершилось статусом " + response.statusCode());
        }
    }

    private URI uri(String path) {
        return URI.create(hubBaseUrl + path);
    }

    private String enc(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    private String stripTrailingSlash(String value) {
        if (value == null || value.isBlank()) {
            return "http://127.0.0.1";
        }
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    @PreDestroy
    public void shutdown() {
        executor.shutdownNow();
    }
}
