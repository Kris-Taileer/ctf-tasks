package ru.avito.iot.hivehub.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import ru.avito.iot.hivehub.bootstrap.DatabaseSeeder;
import ru.avito.iot.hivehub.model.Role;
import ru.avito.iot.hivehub.model.UserAccount;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AccountService {
    private final JdbcTemplate jdbc;

    public AccountService(JdbcTemplate jdbc, DatabaseSeeder databaseSeeder) {
        this.jdbc = jdbc;
    }

    public Optional<UserAccount> authenticate(String username, String password) {
        UserAccount account = find(username).orElse(null);
        if (account == null || !account.password().equals(password)) {
            return Optional.empty();
        }
        return Optional.of(account);
    }

    public Optional<UserAccount> find(String username) {
        return jdbc.query("""
                        SELECT username, display_name, password
                        FROM users
                        WHERE username = ?
                        """,
                (rs, rowNum) -> new UserAccount(
                        rs.getString("username"),
                        rs.getString("display_name"),
                        rs.getString("password"),
                        roles(rs.getString("username"))
                ),
                username
        ).stream().findFirst();
    }

    public UserAccount updateDisplayName(UserAccount account, String displayName) {
        String normalized = normalizeDisplayName(displayName);
        jdbc.update("UPDATE users SET display_name = ? WHERE username = ?", normalized, account.username());
        return find(account.username()).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "учетная запись больше не существует"));
    }

    public UserAccount changePassword(UserAccount account, String currentPassword, String newPassword) {
        if (!account.password().equals(currentPassword)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "текущий пароль указан неверно");
        }
        String normalized = normalizePassword(newPassword);
        jdbc.update("UPDATE users SET password = ? WHERE username = ?", normalized, account.username());
        return find(account.username()).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "учетная запись больше не существует"));
    }

    private String normalizeDisplayName(String value) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "отображаемое имя обязательно");
        }
        if (normalized.length() > 160) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "отображаемое имя слишком длинное");
        }
        return normalized;
    }

    private String normalizePassword(String value) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.length() < 8) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "новый пароль должен содержать минимум 8 символов");
        }
        if (normalized.length() > 200) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "новый пароль слишком длинный");
        }
        return normalized;
    }

    private Set<Role> roles(String username) {
        return jdbc.queryForList("SELECT role FROM user_roles WHERE username = ?", String.class, username)
                .stream()
                .map(Role::valueOf)
                .collect(Collectors.toSet());
    }
}
