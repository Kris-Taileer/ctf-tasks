package ru.avito.iot.hivehub.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class EventLogService {
    private final JdbcTemplate jdbc;

    public EventLogService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void record(String category, String severity, String actor, String target, String summary, String details) {
        jdbc.update("""
                INSERT INTO operation_events(occurred_at, category, severity, actor, target, summary, details)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, Instant.now(), category, severity, actor, target, summary, details);
        trim();
    }

    public List<OperationEvent> latest(int limit) {
        int bounded = Math.max(1, Math.min(limit, 200));
        return jdbc.query("""
                        SELECT id, occurred_at, category, severity, actor, target, summary, details
                        FROM operation_events
                        ORDER BY occurred_at DESC, id DESC
                        LIMIT ?
                        """,
                (rs, rowNum) -> new OperationEvent(
                        rs.getLong("id"),
                        rs.getObject("occurred_at", Instant.class),
                        rs.getString("category"),
                        rs.getString("severity"),
                        rs.getString("actor"),
                        rs.getString("target"),
                        rs.getString("summary"),
                        rs.getString("details")
                ),
                bounded);
    }

    private void trim() {
        jdbc.update("""
                DELETE FROM operation_events
                WHERE id NOT IN (
                    SELECT id FROM operation_events
                    ORDER BY occurred_at DESC, id DESC
                    LIMIT 500
                )
                """);
    }

    public record OperationEvent(
            long id,
            Instant occurredAt,
            String category,
            String severity,
            String actor,
            String target,
            String summary,
            String details
    ) {
    }
}
