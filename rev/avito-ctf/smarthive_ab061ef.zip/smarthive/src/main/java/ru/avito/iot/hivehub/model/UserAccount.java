package ru.avito.iot.hivehub.model;

import java.util.Set;

public record UserAccount(
        String username,
        String displayName,
        String password,
        Set<Role> roles
) {
    public boolean hasRole(Role role) {
        return roles.contains(role);
    }
}
