package ru.avito.iot.hivehub.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class PageController {
    @GetMapping({"/overview", "/devices", "/automation", "/trace", "/profile"})
    public String operationsPage() {
        return "forward:/index.html";
    }

    @GetMapping("/favicon.ico")
    public RedirectView favicon() {
        return new RedirectView("/favicon.svg");
    }
}
