package ru.avito.iot.hivehub.model;

public enum DeviceKind {
    LANDING_GATE,
    NECTAR_DRAINAGE,
    BROOD_INCUBATOR,
    AUDIO
}
