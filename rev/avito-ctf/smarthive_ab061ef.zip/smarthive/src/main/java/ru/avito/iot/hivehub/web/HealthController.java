package ru.avito.iot.hivehub.web;

import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

@RestController
public class HealthController {
    private final JdbcTemplate jdbc;

    public HealthController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        try {
            Integer result = jdbc.queryForObject("SELECT 1", Integer.class);
            return ResponseEntity.ok(Map.of(
                    "ok", true,
                    "database", "h2",
                    "databaseOk", Integer.valueOf(1).equals(result),
                    "checkedAt", Instant.now()
            ));
        } catch (DataAccessException exception) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of(
                    "ok", false,
                    "database", "h2",
                    "databaseOk", false,
                    "message", "h2 check failed",
                    "checkedAt", Instant.now()
            ));
        }
    }
}
