package ru.avito.iot.hivehub.service;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import ru.avito.iot.hivehub.model.Device;

import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class DeviceStatusStream {
    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();

    public SseEmitter subscribe() {
        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);
        emitters.add(emitter);
        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        emitter.onError(ignored -> emitters.remove(emitter));
        return emitter;
    }

    public void publish(Device device, String actor) {
        DeviceStatusUpdate update = new DeviceStatusUpdate(
                device.id(),
                device.enabled(),
                device.updatedAt(),
                actor
        );
        for (SseEmitter emitter : emitters) {
            send(emitter, "device-status", update);
        }
    }

    private void send(SseEmitter emitter, String name, Object data) {
        try {
            emitter.send(SseEmitter.event().name(name).data(data));
        } catch (IOException | RuntimeException e) {
            emitters.remove(emitter);
            try {
                emitter.complete();
            } catch (RuntimeException ignored) {
            }
        }
    }

    public record DeviceStatusUpdate(String id, boolean enabled, Instant updatedAt, String actor) {
    }

}
