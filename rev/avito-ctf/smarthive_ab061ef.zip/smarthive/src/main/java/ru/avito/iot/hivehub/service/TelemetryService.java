package ru.avito.iot.hivehub.service;

import jakarta.annotation.PreDestroy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import ru.avito.iot.hivehub.bootstrap.DatabaseSeeder;

import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
public class TelemetryService {
    private final JdbcTemplate jdbc;
    private final EventLogService events;
    private int sampleCount;
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "hive-telemetry-sampler");
        thread.setDaemon(true);
        return thread;
    });

    public TelemetryService(JdbcTemplate jdbc, DatabaseSeeder databaseSeeder, EventLogService events) {
        this.jdbc = jdbc;
        this.events = events;
        executor.scheduleAtFixedRate(this::sample, 1, 3, TimeUnit.SECONDS);
    }

    private void sample() {
        double phase = (System.currentTimeMillis() % 60000) / 60000.0;
        double nectarHumidity = 78.0 + Math.sin(phase * Math.PI * 2) * 2.4;
        double broodTemperature = 34.6 + Math.cos(phase * Math.PI * 2) * 0.2;
        double mainTemperature = 31.3 + Math.sin(phase * Math.PI * 4) * 0.4;
        boolean speakersEnabled = Boolean.TRUE.equals(jdbc.queryForObject(
                "SELECT enabled FROM devices WHERE id = 'hive-speakers'", Boolean.class));
        String speakerVolume = speakersEnabled ? metricValue("hive-speakers", "volume", "40%") : "0%";
        String drainageFlow = metricValue("nectar-drainage", "flow", "2.1 мл/мин");
        String heaterLevel = metricValue("brood-incubator-a", "heater", "38%");

        updateZone("Ряд рамок B", 29.8, nectarHumidity, drainageFlow, nectarHumidity > 80.5 ? "watch" : "stable");
        updateZone("Сота питомника", broodTemperature, 52.0, "99.2%", "stable");
        updateZone("Главная камера", mainTemperature, 58.0, speakerVolume, speakersEnabled ? "active" : "silent");

        jdbc.update("UPDATE device_metrics SET metric_value = ? WHERE device_id = 'nectar-drainage' AND metric_name = 'humidity'",
                format(nectarHumidity, "%"));
        jdbc.update("UPDATE device_metrics SET metric_value = ? WHERE device_id = 'brood-incubator-a' AND metric_name = 'temperature'",
                format(broodTemperature, " C"));
        jdbc.update("UPDATE devices SET load_value = ?, updated_at = ? WHERE id = 'nectar-drainage'",
                drainageFlow, Instant.now());
        jdbc.update("UPDATE devices SET load_value = ?, updated_at = ? WHERE id = 'brood-incubator-a'",
                heaterLevel, Instant.now());
        sampleCount++;
        if (sampleCount % 5 == 0) {
            events.record("telemetry", "info", "hive-telemetry-sampler", "comb-zones",
                    "Срез телеметрии записан",
                    "Влажность нектара: " + format(nectarHumidity, "%")
                            + ", температура расплода: " + format(broodTemperature, " C"));
        }
    }

    private void updateZone(String zone, double temperature, double humidity, String throughput, String state) {
        jdbc.update("""
                UPDATE zone_readings
                SET temperature = ?, humidity = ?, throughput = ?, state = ?, updated_at = ?
                WHERE zone = ?
                """, temperature, humidity, throughput, state, Instant.now(), zone);
    }

    private String format(double value, String suffix) {
        return String.format(Locale.ROOT, "%.1f%s", value, suffix);
    }

    private String metricValue(String deviceId, String metricName, String fallback) {
        List<String> values = jdbc.queryForList("""
                SELECT metric_value
                FROM device_metrics
                WHERE device_id = ? AND metric_name = ?
                """, String.class, deviceId, metricName);
        return values.isEmpty() ? fallback : values.getFirst();
    }

    @PreDestroy
    public void shutdown() {
        executor.shutdownNow();
    }
}
