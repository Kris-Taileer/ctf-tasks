package ru.avito.iot.hivehub.bootstrap;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import ru.avito.iot.hivehub.config.HiveProperties;
import ru.avito.iot.hivehub.model.DeviceKind;
import ru.avito.iot.hivehub.model.Role;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

@Service
public class DatabaseSeeder {
    private final JdbcTemplate jdbc;
    private final HiveProperties properties;

    public DatabaseSeeder(JdbcTemplate jdbc, HiveProperties properties) {
        this.jdbc = jdbc;
        this.properties = properties;
        seed();
    }

    private void seed() {
        seedUsers();
        seedDevices();
        seedZones();
        seedIncidents();
        seedAutomation();
        seedTopology();
    }

    private void seedUsers() {
        upsertUser(properties.lowUser(), "Подрядчик акустической подсистемы", properties.lowPassword(), Set.of(Role.AUDIO_OPERATOR));
        upsertUser(properties.engineerUser(), "Дежурный инженер улья", properties.engineerPassword(), Set.of(Role.AUDIO_OPERATOR, Role.ENGINEER));
    }

    private void upsertUser(String username, String displayName, String password, Set<Role> roles) {
        jdbc.update("""
                MERGE INTO users KEY(username) VALUES (?, ?, ?)
                """, username, displayName, password);
        jdbc.update("DELETE FROM user_roles WHERE username = ?", username);
        roles.forEach(role -> jdbc.update("INSERT INTO user_roles(username, role) VALUES (?, ?)", username, role.name()));
    }

    private void seedDevices() {
        upsertDevice("landing-gate", "Умные летковые ворота", "Внешняя стенка улья", DeviceKind.LANDING_GATE, true, true,
                "lgw-4.18.2", "94%", "18%", "цикл распознавания", Set.of(Role.ENGINEER),
                Map.of("camera", "готова", "confidence", "96%", "queue", "7 прилетов", "servo", "4.1 мс"));
        upsertDevice("nectar-drainage", "Дренаж влажности нектара", "Ряд рамок B", DeviceKind.NECTAR_DRAINAGE, true, true,
                "ndr-2.7.9", "88%", "34%", "цикл готов", Set.of(Role.ENGINEER),
                Map.of("humidity", "78.4%", "flow", "2.1 мл/мин", "valve", "закрыт"));
        upsertDevice("brood-incubator-a", "Инкубатор ячеек расплода A", "Сота питомника", DeviceKind.BROOD_INCUBATOR, true, true,
                "inc-6.3.1", "91%", "47%", "тепловое удержание", Set.of(Role.ENGINEER),
                Map.of("temperature", "34.6 C", "viability", "99.2%", "heater", "38%"));
        upsertDevice("hive-speakers", "Акустические успокаивающие динамики", "Главная камера", DeviceKind.AUDIO, true, true,
                "aud-3.11.0", "97%", "40%", "успокаивающий цикл", Set.of(Role.AUDIO_OPERATOR, Role.ENGINEER),
                Map.of("track", "forager-bed-03", "volume", "40%", "health", "штатно"));
    }

    private void upsertDevice(
            String id,
            String title,
            String location,
            DeviceKind kind,
            boolean online,
            boolean enabled,
            String firmware,
            String signal,
            String load,
            String state,
            Set<Role> roles,
            Map<String, String> metrics
    ) {
        jdbc.update("""
                MERGE INTO devices KEY(id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, id, title, location, kind.name(), online, enabled, firmware, signal, load, state, Instant.now());
        jdbc.update("DELETE FROM device_permissions WHERE device_id = ?", id);
        roles.forEach(role -> jdbc.update("INSERT INTO device_permissions(device_id, role) VALUES (?, ?)", id, role.name()));
        jdbc.update("DELETE FROM device_metrics WHERE device_id = ?", id);
        metrics.forEach((name, value) -> jdbc.update("INSERT INTO device_metrics(device_id, metric_name, metric_value) VALUES (?, ?, ?)", id, name, value));
    }

    private void seedZones() {
        jdbc.update("DELETE FROM zone_readings WHERE zone IN ('Outer wall', 'Frame row B', 'Nursery comb', 'Main chamber')");
        upsertZone("Внешняя стенка", "Летковые ворота", 24.1, 61.0, "96%", "clear");
        upsertZone("Ряд рамок B", "Дренаж нектара", 29.8, 78.4, "2.1 мл/мин", "watch");
        upsertZone("Сота питомника", "Инкубатор расплода A", 34.6, 52.0, "99.2%", "stable");
        upsertZone("Главная камера", "Акустическая подсистема", 31.3, 58.0, "40%", "active");
    }

    private void upsertZone(String zone, String subsystem, double temperature, double humidity, String throughput, String state) {
        jdbc.update("""
                MERGE INTO zone_readings KEY(zone)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, zone, subsystem, temperature, humidity, throughput, state, Instant.now());
    }

    private void seedIncidents() {
        upsertIncident("nectar-humidity-b", "warning", "Влажность растет в нектарном ряду B", "nectar-drainage",
                "Дренажный цикл справляется, но тренд остается выше целевого диапазона.", "watch");
        upsertIncident("landing-camera-dust", "info", "Контраст летковой камеры снизился", "landing-gate",
                "Уверенность распознавания остается в пределах для автоматического открытия.", "open");
    }

    private void upsertIncident(String id, String severity, String title, String deviceId, String detail, String state) {
        jdbc.update("""
                MERGE INTO incidents KEY(id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, id, severity, title, deviceId, detail, state, Instant.now());
    }

    private void seedAutomation() {
        Instant now = Instant.now();
        upsertAutomation("gate-bee-recognition", "Распознаватель летковых ворот", "уверенность камеры > 96%", "открыть летковые ворота на 4 с", true, now.minusSeconds(12));
        upsertAutomation("nectar-drainage-b", "Контроль влажности нектара", "влажность > 82% в течение 90 с", "импульс дренажного клапана B", true, now.minusSeconds(4 * 60));
        upsertAutomation("brood-thermal-a", "Тепловой контур расплода", "температура вне 34.1-35.0 C", "скорректировать нагрев инкубатора", true, now.minusSeconds(51));
        upsertAutomation("acoustic-monitor", "Монитор акустического комфорта", "акустический цикл прерван", "восстановить успокаивающий профиль", true, now.minusSeconds(18 * 60));
    }

    private void upsertAutomation(String id, String title, String trigger, String action, boolean enabled, Instant lastRunAt) {
        jdbc.update("""
                MERGE INTO automation_rules KEY(id)
                VALUES (?, ?, ?, ?, ?, ?)
                """, id, title, trigger, action, enabled, lastRunAt);
    }

    private void seedTopology() {
        upsertHop("edge-router", "online", "прием запросов", "7 мс", 1);
        upsertHop("auth-gateway", "online", "сессия и идентификация оператора", "4 мс", 2);
        upsertHop("device-orchestrator", "online", "отправка команд устройствам", "12 мс", 3);
        upsertHop("maintenance-console", "idle", "автоматизация дежурного инженера", "резерв", 4);
    }

    private void upsertHop(String service, String state, String responsibility, String latency, int sortOrder) {
        jdbc.update("""
                MERGE INTO route_hops KEY(service)
                VALUES (?, ?, ?, ?, ?)
                """, service, state, responsibility, latency, sortOrder);
    }
}
