package ru.avito.iot.hivehub.web;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.avito.iot.hivehub.service.DebugAuditLog;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class RequestLoggingFilter extends OncePerRequestFilter {
    private final DebugAuditLog debugLog;

    public RequestLoggingFilter(DebugAuditLog debugLog) {
        this.debugLog = debugLog;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        debugLog.append("edge-router", describe(request));
        filterChain.doFilter(request, response);
    }

    private String describe(HttpServletRequest request) {
        StringBuilder builder = new StringBuilder();
        builder.append(request.getMethod()).append(' ').append(request.getRequestURI());
        String query = canonicalQuery(request);
        if (!query.isBlank()) {
            builder.append('?').append(query);
        }
        builder.append(" remote=").append(request.getRemoteAddr());
        String userAgent = request.getHeader("User-Agent");
        if (userAgent != null && !userAgent.isBlank()) {
            builder.append(" ua=").append(encode(userAgent));
        }
        return builder.toString();
    }

    private String canonicalQuery(HttpServletRequest request) {
        Map<String, String[]> parameters = request.getParameterMap();
        if (parameters.isEmpty()) {
            return "";
        }
        List<String> parts = new ArrayList<>();
        parameters.entrySet().stream()
                .sorted(Comparator.comparing(Map.Entry::getKey))
                .forEach(entry -> {
                    String name = encode(entry.getKey());
                    String[] values = entry.getValue();
                    if (values == null || values.length == 0) {
                        parts.add(name + "=");
                        return;
                    }
                    for (String value : values) {
                        parts.add(name + "=" + encode(value));
                    }
                });
        return String.join("&", parts);
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8);
    }
}
