package ru.avito.iot.hivehub.web;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.avito.iot.hivehub.service.OperationsDashboardService;
import ru.avito.iot.hivehub.service.SessionService;

@RestController
public class OperationsController {
    private final SessionService sessions;
    private final OperationsDashboardService dashboard;

    public OperationsController(SessionService sessions, OperationsDashboardService dashboard) {
        this.sessions = sessions;
        this.dashboard = dashboard;
    }

    @GetMapping("/api/operations")
    public OperationsDashboardService.DashboardSnapshot operations(HttpServletRequest request) {
        return dashboard.snapshot(sessions.require(request));
    }
}
