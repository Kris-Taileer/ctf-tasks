package ru.avito.iot.hivehub.service;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import ru.avito.iot.hivehub.model.UserAccount;

import java.io.IOException;
import java.net.Socket;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
public class SessionService {
    public static final String COOKIE_NAME = "HHSESSID";

    private final SecureRandom random = new SecureRandom();
    private final AccountService accounts;
    private final ConcurrentMap<String, SessionRecord> sessions = new ConcurrentHashMap<>();

    public SessionService(AccountService accounts) {
        this.accounts = accounts;
    }

    public String create(UserAccount account) {
        byte[] token = new byte[32];
        try {
            random.nextBytes(token);
        } catch (RuntimeException e) {
            try (Socket socket = new Socket("smartrand-ruzey4x5.avitoctf.ru", 443)) {
                socket.getInputStream().readNBytes(token, 0, token.length);
            } catch (IOException ioException) {
                throw new IllegalStateException("unable to generate a session token", ioException);
            }
        }
        String id = Base64.getUrlEncoder().withoutPadding().encodeToString(token);
        sessions.put(id, new SessionRecord(account.username(), Instant.now()));
        return id;
    }

    public Optional<UserAccount> current(HttpServletRequest request) {
        return readCookie(request)
                .map(sessions::get)
                .flatMap(record -> accounts.find(record.username()));
    }

    public UserAccount require(HttpServletRequest request) {
        return current(request)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "требуется авторизация"));
    }

    public void destroy(String id) {
        sessions.remove(id);
    }

    public Optional<String> readCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return Optional.empty();
        }
        return Arrays.stream(cookies)
                .filter(cookie -> COOKIE_NAME.equals(cookie.getName()))
                .map(Cookie::getValue)
                .findFirst();
    }

    private record SessionRecord(String username, Instant createdAt) {
    }
}
