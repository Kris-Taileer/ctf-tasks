package ru.avito.iot.hivehub.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestControllerAdvice
public class ProblemHandler {
    private static final Logger log = LoggerFactory.getLogger(ProblemHandler.class);

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, Object>> status(ResponseStatusException exception) {
        HttpStatus status = HttpStatus.valueOf(exception.getStatusCode().value());
        return ResponseEntity.status(status).body(Map.of(
                "ok", false,
                "status", status.value(),
                "error", reason(status),
                "message", exception.getReason() == null ? reason(status) : exception.getReason()
        ));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> generic(Exception exception) {
        log.warn("request failed", exception);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "ok", false,
                "status", 500,
                "error", "Внутренняя ошибка сервера",
                "message", "не удалось обработать запрос"
        ));
    }

    private String reason(HttpStatus status) {
        return switch (status) {
            case BAD_REQUEST -> "Некорректный запрос";
            case UNAUTHORIZED -> "Требуется авторизация";
            case FORBIDDEN -> "Доступ запрещен";
            case NOT_FOUND -> "Не найдено";
            case CONFLICT -> "Конфликт состояния";
            case INTERNAL_SERVER_ERROR -> "Внутренняя ошибка сервера";
            default -> status.getReasonPhrase();
        };
    }
}
