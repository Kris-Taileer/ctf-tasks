package ru.avito.iot.hivehub.service;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

@Service
public class FlagResolver {
    public String resolveFlag(HttpServletRequest ignored) {
        return System.getenv("FLAG");
    }
}
