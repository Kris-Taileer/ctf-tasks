package ru.avito.iot.hivehub.model;

import java.time.Instant;
import java.util.Set;

public record Device(
        String id,
        String title,
        String location,
        DeviceKind kind,
        Set<Role> writableBy,
        boolean online,
        boolean enabled,
        Instant updatedAt
) {
    public Device withEnabled(boolean value) {
        return new Device(id, title, location, kind, writableBy, online, value, Instant.now());
    }
}
