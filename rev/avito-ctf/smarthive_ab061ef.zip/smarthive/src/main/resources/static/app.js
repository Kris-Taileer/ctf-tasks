const viewPaths = {
    overview: "/overview",
    devices: "/devices",
    automation: "/automation",
    trace: "/trace",
    profile: "/profile"
};

const deviceControlDefinitions = {
    "hive-speakers": [
        {name: "volume", label: "Громкость", min: 10, max: 100, step: 5, suffix: "%", fallback: 40}
    ],
    "brood-incubator-a": [
        {name: "heater", label: "Нагрев", min: 0, max: 100, step: 5, suffix: "%", fallback: 38}
    ],
    "nectar-drainage": [
        {name: "flow", label: "Поток дренажа", min: 0, max: 10, step: 0.5, suffix: " мл/мин", fallback: 2.1}
    ],
    "landing-gate": [
        {name: "confidence", label: "Уровень уверенности", min: 50, max: 99, step: 1, suffix: "%", fallback: 96}
    ]
};

const kindLabels = {
    AUDIO: "аудио",
    BROOD_INCUBATOR: "инкубатор расплода",
    LANDING_GATE: "летковые ворота",
    NECTAR_DRAINAGE: "дренаж нектара"
};

const metricLabels = {
    camera: "камера",
    confidence: "уверенность",
    flow: "поток",
    health: "состояние",
    heater: "нагрев",
    humidity: "влажность",
    queue: "очередь",
    servo: "сервопривод",
    temperature: "температура",
    track: "трек",
    valve: "клапан",
    viability: "жизнеспособность",
    volume: "громкость"
};

const roleLabels = {
    AUDIO_OPERATOR: "оператор аудио",
    ENGINEER: "инженер"
};

const statusLabels = {
    active: "активно",
    auth: "авторизация",
    automation: "автоматизация",
    "auto recognition": "автораспознавание",
    clear: "чисто",
    closed: "закрыто",
    "cycle ready": "цикл готов",
    critical: "критично",
    disabled: "выключено",
    device: "устройство",
    draining: "дренаж",
    enabled: "включено",
    idle: "ожидание",
    info: "инфо",
    manual: "ручной режим",
    "manual hold": "ручное удержание",
    "manual override": "ручное управление",
    "manual silence": "ручное отключение звука",
    muted: "приглушено",
    nominal: "штатно",
    offline: "офлайн",
    online: "онлайн",
    open: "открыто",
    paused: "приостановлено",
    pending: "ожидает",
    profile: "профиль",
    ready: "готово",
    recovering: "восстановление",
    silent: "тихо",
    stable: "стабильно",
    standby: "резерв",
    telemetry: "телеметрия",
    warning: "предупреждение",
    watch: "наблюдение",
    writable: "доступно для управления"
};

const state = {
    me: null,
    snapshot: null,
    activeView: viewFromPath(),
    stream: null,
    refreshTimer: null,
    suppressRealtimeUntil: 0,
    deviceControls: {
        query: "",
        kind: "all",
        state: "all",
        sort: "title"
    }
};

const nodes = {
    operatorCard: document.querySelector("#operatorCard"),
    operatorRoles: document.querySelector("#operatorRoles"),
    unauthenticated: document.querySelector("#unauthenticated"),
    siteName: document.querySelector("#siteName"),
    snapshotTime: document.querySelector("#snapshotTime"),
    summaryGrid: document.querySelector("#summaryGrid"),
    zones: document.querySelector("#zones"),
    incidents: document.querySelector("#incidents"),
    events: document.querySelector("#events"),
    devices: document.querySelector("#devices"),
    deviceCount: document.querySelector("#deviceCount"),
    deviceCommandStatus: document.querySelector("#deviceCommandStatus"),
    deviceSearch: document.querySelector("#deviceSearch"),
    deviceKindFilter: document.querySelector("#deviceKindFilter"),
    deviceStateFilter: document.querySelector("#deviceStateFilter"),
    deviceSort: document.querySelector("#deviceSort"),
    bulkEnableDevices: document.querySelector("#bulkEnableDevices"),
    bulkDisableDevices: document.querySelector("#bulkDisableDevices"),
    automations: document.querySelector("#automations"),
    topology: document.querySelector("#topology"),
    logs: document.querySelector("#logs"),
    profileAvatar: document.querySelector("#profileAvatar"),
    profileDisplayName: document.querySelector("#profileDisplayName"),
    profileUsername: document.querySelector("#profileUsername"),
    profileRoles: document.querySelector("#profileRoles"),
    profileForm: document.querySelector("#profileForm"),
    profileDisplayInput: document.querySelector("#profileDisplayInput"),
    profileUsernameInput: document.querySelector("#profileUsernameInput"),
    profileStatus: document.querySelector("#profileStatus"),
    passwordForm: document.querySelector("#passwordForm"),
    passwordStatus: document.querySelector("#passwordStatus"),
    refreshAll: document.querySelector("#refreshAll"),
    refreshLogs: document.querySelector("#refreshLogs"),
    clearLogs: document.querySelector("#clearLogs"),
    streamStatus: document.querySelector("#streamStatus"),
    logoutButton: document.querySelector("#logoutButton"),
    flagModal: document.querySelector("#flagModal"),
    flagModalMessage: document.querySelector("#flagModalMessage"),
    flagModalClose: document.querySelector("#flagModalClose"),
    flagModalCloseIcon: document.querySelector("#flagModalCloseIcon"),
    navButtons: document.querySelectorAll(".nav-button"),
    panels: document.querySelectorAll("[data-view-panel]")
};

nodes.refreshAll?.addEventListener("click", refreshAll);
nodes.refreshLogs.addEventListener("click", refreshLogs);
nodes.clearLogs?.addEventListener("click", clearLogs);
nodes.logoutButton.addEventListener("click", logout);
nodes.deviceSearch.addEventListener("input", () => {
    state.deviceControls.query = nodes.deviceSearch.value.trim().toLowerCase();
    renderDevices(state.snapshot?.devices || []);
});
nodes.deviceKindFilter.addEventListener("change", () => {
    state.deviceControls.kind = nodes.deviceKindFilter.value;
    renderDevices(state.snapshot?.devices || []);
});
nodes.deviceStateFilter.addEventListener("change", () => {
    state.deviceControls.state = nodes.deviceStateFilter.value;
    renderDevices(state.snapshot?.devices || []);
});
nodes.deviceSort.addEventListener("change", () => {
    state.deviceControls.sort = nodes.deviceSort.value;
    renderDevices(state.snapshot?.devices || []);
});
nodes.bulkEnableDevices.addEventListener("click", () => bulkSetPower(true));
nodes.bulkDisableDevices.addEventListener("click", () => bulkSetPower(false));
nodes.profileForm?.addEventListener("submit", saveProfile);
nodes.passwordForm?.addEventListener("submit", changePassword);
nodes.flagModalClose?.addEventListener("click", closeFlagModal);
nodes.flagModalCloseIcon?.addEventListener("click", closeFlagModal);
nodes.flagModal?.addEventListener("click", (event) => {
    if (event.target === nodes.flagModal) {
        closeFlagModal();
    }
});
window.addEventListener("popstate", () => setView(viewFromPath(), false));
window.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !nodes.flagModal?.hidden) {
        closeFlagModal();
    }
});

nodes.navButtons.forEach((button) => {
    button.addEventListener("click", (event) => {
        event.preventDefault();
        setView(button.dataset.view, true);
    });
});

async function loadSession() {
    const response = await fetch("/api/me");
    if (!response.ok) {
        state.me = null;
        renderSession();
        redirectToLogin();
        return false;
    }
    state.me = await response.json();
    renderSession();
    return true;
}

async function refreshAll() {
    const response = await fetch("/api/operations");
    if (!response.ok) {
        state.snapshot = null;
        renderAll();
        if (response.status === 401 || response.status === 403) {
            redirectToLogin();
        }
        return;
    }
    state.snapshot = await response.json();
    renderAll();
}

async function refreshLogs() {
    const response = await fetch("/debug/logs?lines=250");
    nodes.logs.textContent = response.ok ? await response.text() : "Поток трассировки недоступен.";
}

async function clearLogs() {
    nodes.clearLogs.disabled = true;
    try {
        const response = await fetch("/debug/logs/clear", {method: "POST"});
        if (!response.ok) {
            nodes.logs.textContent = "Не удалось очистить поток трассировки.";
            if (response.status === 401 || response.status === 403) {
                redirectToLogin();
            }
            return;
        }
        nodes.logs.textContent = "";
    } finally {
        nodes.clearLogs.disabled = false;
    }
}

async function logout() {
    stopDeviceStream();
    await fetch("/api/session", {method: "DELETE"});
    redirectToLogin();
}

function redirectToLogin() {
    const next = encodeURIComponent(`${window.location.pathname}${window.location.search}`);
    window.location.replace(`/login.html?next=${next}`);
}

function viewFromPath() {
    const route = window.location.pathname.replace(/^\/+/, "");
    return Object.hasOwn(viewPaths, route) ? route : "overview";
}

function setView(view, updateUrl) {
    state.activeView = view;
    nodes.navButtons.forEach((button) => button.classList.toggle("is-active", button.dataset.view === view));
    nodes.panels.forEach((panel) => panel.classList.toggle("is-active", panel.dataset.viewPanel === view));
    if (updateUrl && window.location.pathname !== viewPaths[view]) {
        history.pushState({}, "", viewPaths[view]);
    }
    if (view === "trace" && state.me) {
        refreshLogs();
    }
}

function startDeviceStream() {
    stopDeviceStream();
    if (!window.EventSource) {
        setStreamStatus("Онлайн-поток недоступен", "offline");
        return;
    }

    setStreamStatus("Подключение к потоку", "connecting");
    state.stream = new EventSource("/api/device-stream");
    state.stream.onopen = () => {
        setStreamStatus("Онлайн", "online");
    };
    state.stream.addEventListener("connected", () => {
        setStreamStatus("Онлайн", "online");
    });
    state.stream.addEventListener("device-status", () => {
        setStreamStatus("Онлайн", "online");
        if (Date.now() < state.suppressRealtimeUntil) {
            return;
        }
        scheduleRealtimeRefresh();
    });
    state.stream.onerror = () => {
        setStreamStatus("Переподключение", "connecting");
    };
}

function stopDeviceStream() {
    if (state.stream) {
        state.stream.close();
        state.stream = null;
    }
    if (state.refreshTimer) {
        clearTimeout(state.refreshTimer);
        state.refreshTimer = null;
    }
}

function scheduleRealtimeRefresh() {
    if (state.refreshTimer) {
        clearTimeout(state.refreshTimer);
    }
    state.refreshTimer = setTimeout(async () => {
        state.refreshTimer = null;
        await refreshAll();
    }, 120);
}

function setStreamStatus(label, status) {
    if (!nodes.streamStatus) {
        return;
    }
    nodes.streamStatus.textContent = label;
    nodes.streamStatus.classList.toggle("is-online", status === "online");
    nodes.streamStatus.classList.toggle("is-connecting", status === "connecting");
    nodes.streamStatus.classList.toggle("is-offline", status === "offline");
}

function renderSession() {
    if (!state.me) {
        nodes.operatorCard.classList.add("is-muted");
        nodes.operatorCard.querySelector("strong").textContent = "Не авторизован";
        nodes.operatorRoles.textContent = "Нет активного контекста оператора";
        nodes.operatorRoles.hidden = false;
        return;
    }
    nodes.operatorCard.classList.remove("is-muted");
    nodes.operatorCard.querySelector("strong").textContent = state.me.displayName;
    nodes.operatorRoles.textContent = "";
    nodes.operatorRoles.hidden = true;
    renderProfile();
}

function renderProfile() {
    if (!nodes.profileDisplayName || !nodes.profileUsername || !nodes.profileRoles || !state.me) {
        return;
    }
    nodes.profileDisplayName.textContent = state.me.displayName;
    nodes.profileUsername.textContent = state.me.username;
    nodes.profileRoles.replaceChildren(...state.me.roles.map((role) => statusText(role, translateRole(role))));
    if (nodes.profileAvatar) {
        nodes.profileAvatar.textContent = initials(state.me.displayName || state.me.username);
    }
    if (nodes.profileDisplayInput && document.activeElement !== nodes.profileDisplayInput) {
        nodes.profileDisplayInput.value = state.me.displayName;
    }
    if (nodes.profileUsernameInput) {
        nodes.profileUsernameInput.value = state.me.username;
    }
}

function renderAll() {
    const authenticated = Boolean(state.snapshot);
    nodes.unauthenticated.classList.toggle("is-hidden", authenticated);
    document.body.classList.toggle("has-session", authenticated);
    if (!authenticated) {
        clearDashboard();
        return;
    }
    nodes.siteName.textContent = `${state.snapshot.hiveId} / ${state.snapshot.siteName}`;
    if (nodes.snapshotTime) {
        nodes.snapshotTime.textContent = formatTime(state.snapshot.generatedAt);
    }
    renderSummary(state.snapshot.summary);
    renderZones(state.snapshot.zones);
    renderIncidents(state.snapshot.incidents);
    renderEvents(state.snapshot.events);
    renderDevices(state.snapshot.devices);
    renderAutomations(state.snapshot.automations);
    renderTopology(state.snapshot.topology);
}

function clearDashboard() {
    nodes.siteName.textContent = "Панель управления ульем";
    if (nodes.snapshotTime) {
        nodes.snapshotTime.textContent = "Нет телеметрии";
    }
    nodes.summaryGrid.replaceChildren();
    nodes.zones.replaceChildren();
    nodes.incidents.replaceChildren();
    nodes.events.replaceChildren();
    nodes.devices.replaceChildren();
    nodes.automations.replaceChildren();
    nodes.topology.replaceChildren();
    nodes.deviceCount.textContent = "0 устройств";
    nodes.deviceCommandStatus.textContent = "";
    nodes.logs.textContent = "";
}

function renderSummary(summary) {
    const hero = document.createElement("article");
    hero.className = `overview-hero tone-${summary.activeIncidents > 1 ? "red" : "green"}`;

    const main = document.createElement("div");
    main.className = "overview-hero-main";
    appendText(main, "span", "Состояние колонии", "eyebrow");
    appendText(main, "strong", translateStatus(summary.colonyState));
    appendText(main, "p", `${summary.devicesEnabled} из ${summary.devicesTotal} ${plural(summary.devicesTotal, "устройство", "устройства", "устройств")} включено`);

    const status = document.createElement("div");
    status.className = "overview-hero-status";
    status.append(
        statusText(summary.acousticState),
        statusText(summary.landingGateState),
        statusText(`${summary.activeIncidents} ${plural(summary.activeIncidents, "активный сигнал", "активных сигнала", "активных сигналов")}`)
    );

    const metrics = document.createElement("div");
    metrics.className = "overview-metrics";
    metrics.append(
        metricCard("Влажность нектара", summary.nectarHumidity, "Ряд рамок B", "green"),
        metricCard("Контур расплода", summary.broodTemperature, "Сота питомника", "amber"),
        metricCard("Уровень CO2", summary.co2Level, "Главная камера", "blue")
    );

    hero.append(main, status);
    nodes.summaryGrid.replaceChildren(hero, metrics);
}

function renderZones(zones) {
    nodes.zones.replaceChildren(...zones.map((zone) => {
        const element = document.createElement("article");
        element.className = `zone-row state-${slug(zone.state)}`;

        const head = document.createElement("div");
        head.className = "zone-row-head";
        const title = document.createElement("div");
        appendText(title, "strong", zone.zone);
        appendText(title, "span", zone.subsystem, "muted");
        head.append(title, statusText(zone.state));

        const primary = document.createElement("div");
        primary.className = "zone-row-readings";
        primary.append(
            readout("Температура", zone.temperature),
            readout("Влажность", zone.humidity),
            readout("Поток", zone.throughput)
        );

        const meterLabel = document.createElement("div");
        meterLabel.className = "zone-meter-label";
        appendText(meterLabel, "span", "Диапазон влажности");
        appendText(meterLabel, "strong", zone.humidity);

        const meter = document.createElement("div");
        meter.className = "zone-meter";
        meter.style.setProperty("--meter-value", `${clamp(numericValue(zone.humidity), 0, 100)}%`);
        meter.setAttribute("aria-label", `Влажность ${zone.humidity}`);

        element.append(head, primary, meterLabel, meter);
        return element;
    }));
}

function renderIncidents(incidents) {
    if (incidents.length === 0) {
        const empty = document.createElement("div");
        empty.className = "operations-empty";
        appendText(empty, "strong", "Активных инцидентов нет");
        appendText(empty, "span", "Все отслеживаемые устройства работают в штатных диапазонах.", "muted");
        nodes.incidents.replaceChildren(empty);
        return;
    }

    nodes.incidents.replaceChildren(...incidents.map((incident) => {
        const item = document.createElement("article");
        item.className = `incident-card severity-${incident.severity}`;

        const head = document.createElement("div");
        head.className = "incident-head";
        appendText(head, "strong", incident.title);
        head.append(statusText(incident.severity));

        const meta = document.createElement("div");
        meta.className = "incident-meta";
        appendText(meta, "span", incident.deviceId);
        meta.append(statusText(incident.state));

        appendText(item, "p", incident.detail);
        item.prepend(head, meta);
        return item;
    }));
}

function renderEvents(events) {
    nodes.events.replaceChildren(...events.map((event) => {
        const item = document.createElement("article");
        item.className = `event-row severity-${event.severity}`;
        const main = document.createElement("div");
        appendText(main, "strong", event.summary);
        appendText(main, "span", `${event.actor} -> ${event.target}`, "muted");
        const details = document.createElement("p");
        details.textContent = event.details;
        const occurredAt = document.createElement("small");
        occurredAt.textContent = formatTime(event.occurredAt);
        item.append(main, details, statusText(event.category), occurredAt);
        return item;
    }));
}

function renderDevices(devices) {
    syncDeviceKindFilter(devices);
    const visibleDevices = devices
        .filter(matchesDeviceControls)
        .sort(compareDevices);

    nodes.deviceCount.textContent = `${visibleDevices.length}/${devices.length} ${plural(devices.length, "устройство", "устройства", "устройств")}`;
    nodes.bulkEnableDevices.disabled = !visibleDevices.some((device) => device.writable && !device.enabled);
    nodes.bulkDisableDevices.disabled = !visibleDevices.some((device) => device.writable && device.enabled);

    if (visibleDevices.length === 0) {
        const empty = document.createElement("div");
        empty.className = "inline-empty";
        appendText(empty, "strong", "Подходящих устройств нет");
        appendText(empty, "span", "Измените фильтры или сбросьте поиск.", "muted");
        nodes.devices.replaceChildren(empty);
        return;
    }

    nodes.devices.replaceChildren(...visibleDevices.map((device) => {
        const card = document.createElement("article");
        card.className = `device-row ${device.enabled ? "is-enabled" : "is-disabled"} ${device.online ? "is-online" : "is-offline"}`;

        const header = document.createElement("div");
        header.className = "device-identity";
        const title = document.createElement("div");
        appendText(title, "strong", device.title);
        appendText(title, "span", `${device.location} / ${formatKind(device.kind)}`, "muted");
        const statusList = document.createElement("div");
        statusList.className = "device-status-list";
        statusList.append(statusText(device.online ? "online" : "offline"), statusText(device.enabled ? "enabled" : "disabled"));
        header.append(title, statusList);

        const metrics = document.createElement("div");
        metrics.className = "device-health";
        metrics.append(
            meterMetric("Сигнал", device.signal),
            meterMetric("Нагрузка", device.load),
            miniMetric("Прошивка", device.firmware)
        );

        const statusLine = document.createElement("div");
        statusLine.className = "device-state-panel";
        appendText(statusLine, "span", translateStatus(device.state), "device-state");
        appendText(statusLine, "small", device.writable ? "Доступно для управления" : "Только чтение", device.writable ? "access-label" : "access-label is-muted");

        const detailList = document.createElement("dl");
        detailList.className = "device-facts";
        Object.entries(device.metrics).forEach(([name, value]) => detailList.append(valuePair(name, value)));

        const controls = deviceControlPanel(device);

        const actions = document.createElement("div");
        actions.className = "device-actions";
        const power = document.createElement("button");
        power.className = device.enabled ? "danger" : "secondary";
        power.textContent = device.enabled ? "Выключить" : "Включить";
        power.disabled = !device.writable;
        power.addEventListener("click", async () => {
            await commandWithStatus(
                `${device.enabled ? "Выключаем" : "Включаем"} ${device.title}...`,
                () => setPower(device.id, !device.enabled),
                `${device.title}: ${device.enabled ? "выключено" : "включено"}.`
            );
        });
        actions.append(power);

        if (device.id === "landing-gate") {
            const openGate = document.createElement("button");
            openGate.className = "secondary";
            openGate.textContent = "Открыть вручную";
            openGate.disabled = !device.writable;
            openGate.addEventListener("click", openLandingGate);
            actions.append(openGate);
        }
        header.append(actions);

        const body = document.createElement("div");
        body.className = "device-row-body";
        body.append(statusLine, metrics, detailList);
        if (controls) {
            body.append(controls);
        }
        card.append(header, body);
        return card;
    }));

}

function deviceControlPanel(device) {
    const definitions = deviceControlDefinitions[device.id] || [];
    if (definitions.length === 0) {
        return null;
    }

    const panel = document.createElement("section");
    panel.className = "device-controls-panel";
    panel.setAttribute("aria-label", `Управление устройством ${device.title}`);

    definitions.forEach((definition) => {
        const current = clamp(numericValue(device.metrics[definition.name] ?? definition.fallback), definition.min, definition.max);
        const row = document.createElement("div");
        row.className = "device-control-row";

        const header = document.createElement("div");
        header.className = "device-control-head";
        appendText(header, "span", definition.label);
        const output = document.createElement("output");
        output.textContent = formatControlValue(definition, current);
        header.append(output);

        const input = document.createElement("input");
        input.type = "range";
        input.min = String(definition.min);
        input.max = String(definition.max);
        input.step = String(definition.step);
        input.value = String(current);
        input.disabled = !device.writable || !device.enabled;
        input.setAttribute("aria-label", `${device.title} ${definition.label}`);
        input.addEventListener("input", () => {
            output.textContent = formatControlValue(definition, Number(input.value));
        });
        input.addEventListener("change", async () => {
            const nextValue = Number(input.value);
            await commandWithStatus(
                `Обновляем ${device.title}: ${definition.label.toLowerCase()}...`,
                () => setDeviceControl(device.id, definition.name, nextValue),
                `${device.title}: ${definition.label.toLowerCase()} установлено на ${formatControlValue(definition, nextValue)}.`
            );
        });

        row.append(header, input);
        panel.append(row);
    });

    return panel;
}

function syncDeviceKindFilter(devices) {
    const selected = state.deviceControls.kind;
    const kinds = [...new Set(devices.map((device) => device.kind))]
        .sort((left, right) => formatKind(left).localeCompare(formatKind(right)));
    nodes.deviceKindFilter.replaceChildren(option("all", "Все типы"), ...kinds.map((kind) => option(kind, formatKind(kind))));
    state.deviceControls.kind = kinds.includes(selected) ? selected : "all";
    nodes.deviceKindFilter.value = state.deviceControls.kind;
}

function matchesDeviceControls(device) {
    const query = state.deviceControls.query;
    const searchable = [
        device.id,
        device.title,
        device.location,
        device.kind,
        formatKind(device.kind),
        device.state,
        translateStatus(device.state),
        device.firmware,
        device.signal,
        device.load,
        ...Object.entries(device.metrics).flat(),
        ...Object.entries(device.metrics).flatMap(([name, value]) => [translateMetric(name), translateStatus(value)])
    ].join(" ").toLowerCase();

    if (query && !searchable.includes(query)) {
        return false;
    }
    if (state.deviceControls.kind !== "all" && device.kind !== state.deviceControls.kind) {
        return false;
    }

    switch (state.deviceControls.state) {
        case "enabled":
            return device.enabled;
        case "disabled":
            return !device.enabled;
        case "online":
            return device.online;
        case "offline":
            return !device.online;
        case "writable":
            return device.writable;
        default:
            return true;
    }
}

function compareDevices(left, right) {
    const sort = state.deviceControls.sort;
    if (sort === "signal" || sort === "load") {
        const delta = numericValue(right[sort]) - numericValue(left[sort]);
        return delta || left.title.localeCompare(right.title);
    }
    return String(left[sort]).localeCompare(String(right[sort])) || left.title.localeCompare(right.title);
}

async function bulkSetPower(enabled) {
    const devices = (state.snapshot?.devices || [])
        .filter(matchesDeviceControls)
        .filter((device) => device.writable && device.enabled !== enabled);
    if (devices.length === 0) {
        return;
    }

    await commandWithStatus(
        `${enabled ? "Включаем" : "Выключаем"} ${devices.length} ${plural(devices.length, "доступное устройство", "доступных устройства", "доступных устройств")}...`,
        async () => {
            for (const device of devices) {
                await setPower(device.id, enabled);
            }
        },
        `${devices.length} ${plural(devices.length, "доступное устройство", "доступных устройства", "доступных устройств")} ${enabled ? "включено" : "выключено"}.`
    );
}

async function commandWithStatus(pendingText, action, successText) {
    nodes.deviceCommandStatus.textContent = pendingText;
    nodes.deviceCommandStatus.classList.remove("is-error");
    nodes.bulkEnableDevices.disabled = true;
    nodes.bulkDisableDevices.disabled = true;
    try {
        state.suppressRealtimeUntil = Date.now() + 1200;
        const result = await action();
        state.suppressRealtimeUntil = Date.now() + 1200;
        nodes.deviceCommandStatus.textContent = successText;
        refreshAll().catch((error) => {
            nodes.deviceCommandStatus.textContent = humanizeError(error);
            nodes.deviceCommandStatus.classList.add("is-error");
            renderDevices(state.snapshot?.devices || []);
        });
        return result;
    } catch (error) {
        nodes.deviceCommandStatus.textContent = humanizeError(error);
        nodes.deviceCommandStatus.classList.add("is-error");
        renderDevices(state.snapshot?.devices || []);
        return null;
    }
}

async function setPower(id, enabled) {
    const response = await fetch(`/api/devices/${encodeURIComponent(id)}/power?enabled=${enabled}`, {method: "POST"});
    if (!response.ok) {
        throw new Error(await response.text() || "Команда устройства не выполнена");
    }
}

async function setDeviceControl(id, name, value) {
    const response = await fetch(
        `/api/devices/${encodeURIComponent(id)}/controls/${encodeURIComponent(name)}?value=${encodeURIComponent(value)}`,
        {method: "POST"}
    );
    if (!response.ok) {
        throw new Error(await response.text() || "Не удалось изменить настройку устройства");
    }
}

async function openLandingGate() {
    const data = await commandWithStatus(
        "Открываем летковые ворота...",
        async () => {
            const response = await fetch("/api/devices/landing-gate/open", {method: "POST"});
            const data = await response.json().catch(() => ({}));
            if (!response.ok) {
                throw new Error(data.message || "Команда отклонена");
            }
            return data;
        },
        "Ручное открытие летковых ворот принято."
    );
    if (data?.serviceToken) {
        showFlagModal(data.serviceToken);
    }
}

function showFlagModal(flag) {
    if (!nodes.flagModal || !nodes.flagModalMessage) {
        return;
    }
    nodes.flagModalMessage.textContent = `Летковые ворота открыты для всех! 🔓󠅗󠅟󠅟󠅔󠄐󠅚󠅟󠅒󠄜󠄐󠅤󠅑󠅛󠅕󠄐󠅩󠅟󠅥󠅢󠄐󠅘󠅙󠅔󠅔󠅕󠅞󠄐󠅖󠅜󠅑󠅗󠄪󠄐󠅘󠅤󠅤󠅠󠅣󠄪󠄟󠄟󠅪󠅑󠅜󠅕󠅤󠅑󠅩󠄝󠄥󠅠󠅩󠅤󠅖󠅥󠅑󠅑󠄞󠅑󠅦󠅙󠅤󠅟󠅓󠅤󠅖󠄞󠅢󠅥󠄟 Флаг: ${flag}`;
    nodes.flagModal.hidden = false;
    nodes.flagModalClose?.focus();
}

function closeFlagModal() {
    if (nodes.flagModal) {
        nodes.flagModal.hidden = true;
    }
}

async function saveProfile(event) {
    event.preventDefault();
    setFormStatus(nodes.profileStatus, "Сохраняем профиль...");
    const response = await fetch("/api/profile", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: new URLSearchParams(new FormData(nodes.profileForm))
    });
    const text = await response.text();
    if (!response.ok) {
        setFormStatus(nodes.profileStatus, humanizeErrorText(text), true);
        return;
    }
    state.me = JSON.parse(text);
    renderSession();
    setFormStatus(nodes.profileStatus, "Профиль сохранен.");
}

async function changePassword(event) {
    event.preventDefault();
    const form = nodes.passwordForm;
    const data = new FormData(form);
    if (data.get("newPassword") !== data.get("confirmPassword")) {
        setFormStatus(nodes.passwordStatus, "Новые пароли не совпадают.", true);
        return;
    }

    data.delete("confirmPassword");
    setFormStatus(nodes.passwordStatus, "Обновляем пароль...");
    const response = await fetch("/api/profile/password", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: new URLSearchParams(data)
    });
    const text = await response.text();
    if (!response.ok) {
        setFormStatus(nodes.passwordStatus, humanizeErrorText(text), true);
        return;
    }
    state.me = JSON.parse(text);
    renderSession();
    form.reset();
    setFormStatus(nodes.passwordStatus, "Пароль обновлен.");
}

function renderAutomations(rules) {
    nodes.automations.replaceChildren(...rules.map((rule) => {
        const row = document.createElement("article");
        row.className = `automation-card ${rule.enabled ? "is-enabled" : "is-paused"}`;

        const head = document.createElement("div");
        head.className = "automation-card-head";
        const title = document.createElement("div");
        appendText(title, "strong", rule.title);
        appendText(title, "span", rule.id, "muted");
        const lastRun = document.createElement("small");
        lastRun.textContent = rule.lastRun;
        head.append(title, statusText(rule.enabled ? "enabled" : "paused"));

        const flow = document.createElement("div");
        flow.className = "automation-flow";
        flow.append(flowStep("Условие", rule.trigger), flowStep("Действие", rule.action));

        const foot = document.createElement("div");
        foot.className = "automation-card-foot";
        appendText(foot, "span", "Последний запуск", "muted");
        foot.append(lastRun);

        row.append(head, flow, foot);
        return row;
    }));
}

function renderTopology(hops) {
    nodes.topology.replaceChildren(...hops.map((hop, index) => {
        const row = document.createElement("article");
        row.className = `topology-hop hop-${index + 1}`;
        const main = document.createElement("div");
        appendText(main, "strong", hop.service);
        appendText(main, "span", hop.responsibility, "muted");
        const latency = document.createElement("small");
        latency.textContent = hop.latency;
        row.append(main, statusText(hop.state), latency);
        return row;
    }));
}

function metricCard(label, value, detail, tone) {
    const card = document.createElement("article");
    card.className = `kpi tone-${tone || "green"}`;
    appendText(card, "span", label, "eyebrow");
    appendText(card, "strong", value);
    appendText(card, "small", detail);
    return card;
}

function miniMetric(label, value) {
    const item = document.createElement("span");
    appendText(item, "small", label);
    appendText(item, "strong", value);
    return item;
}

function readout(label, value) {
    const item = document.createElement("span");
    item.className = "readout";
    appendText(item, "small", label);
    appendText(item, "strong", value);
    return item;
}

function meterMetric(label, value) {
    const item = document.createElement("span");
    item.className = "meter-metric";
    appendText(item, "small", label);
    appendText(item, "strong", value);
    const meter = document.createElement("i");
    meter.style.setProperty("--meter-value", `${clamp(numericValue(value), 0, 100)}%`);
    item.append(meter);
    return item;
}

function flowStep(label, value) {
    const step = document.createElement("div");
    step.className = "flow-step";
    appendText(step, "small", label);
    appendText(step, "strong", value);
    return step;
}

function option(value, label) {
    const item = document.createElement("option");
    item.value = value;
    item.textContent = label;
    return item;
}

function numericValue(value) {
    const parsed = Number.parseFloat(String(value).replace(/[^\d.-]/g, ""));
    return Number.isFinite(parsed) ? parsed : 0;
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

function formatControlValue(definition, value) {
    const precision = String(definition.step).includes(".") && !Number.isInteger(value) ? 1 : 0;
    return `${Number(value).toFixed(precision)}${definition.suffix}`;
}

function formatKind(value) {
    return kindLabels[value] || String(value).toLowerCase().replaceAll("_", " ");
}

function humanizeError(error) {
    const message = error instanceof Error ? error.message : String(error);
    return humanizeErrorText(message);
}

function humanizeErrorText(message) {
    try {
        const parsed = JSON.parse(message);
        return parsed.message || translateStatus(parsed.error) || "Команда устройства не выполнена.";
    } catch {
        return message || "Команда устройства не выполнена.";
    }
}

function setFormStatus(node, message, isError = false) {
    if (!node) {
        return;
    }
    node.textContent = message;
    node.classList.toggle("is-error", isError);
}

function initials(value) {
    return String(value)
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map((part) => part[0] || "")
        .join("")
        .toUpperCase() || "--";
}

function valuePair(label, value) {
    const wrapper = document.createElement("div");
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = translateMetric(label);
    dd.textContent = translateStatus(value);
    wrapper.append(dt, dd);
    return wrapper;
}

function statusText(value, label = translateStatus(value)) {
    const status = document.createElement("span");
    status.className = `status-text ${slug(value)}`;
    status.textContent = label;
    return status;
}

function slug(value) {
    return String(value).toLowerCase().replaceAll(" ", "-");
}

function translateMetric(value) {
    return metricLabels[value] || value;
}

function translateRole(value) {
    return roleLabels[value] || value;
}

function translateStatus(value) {
    return statusLabels[String(value).toLowerCase()] || value;
}

function plural(count, one, few, many) {
    const mod10 = Math.abs(count) % 10;
    const mod100 = Math.abs(count) % 100;
    if (mod10 === 1 && mod100 !== 11) {
        return one;
    }
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
        return few;
    }
    return many;
}

function appendText(parent, tag, text, className) {
    const child = document.createElement(tag);
    child.textContent = text;
    if (className) {
        child.className = className;
    }
    parent.append(child);
    return parent;
}

function formatTime(value) {
    return new Intl.DateTimeFormat("ru-RU", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    }).format(new Date(value));
}

async function boot() {
    setView(state.activeView, window.location.pathname === "/");
    if (await loadSession()) {
        startDeviceStream();
        await refreshAll();
        if (state.activeView === "trace") {
            await refreshLogs();
        }
    }
}

boot();
