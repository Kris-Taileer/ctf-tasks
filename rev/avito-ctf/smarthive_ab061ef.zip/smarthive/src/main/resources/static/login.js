const form = document.querySelector("#loginForm");
const statusLine = document.querySelector("#loginStatus");
const params = new URLSearchParams(window.location.search);
const requestedNext = params.get("next") || "/overview";
const next = requestedNext.startsWith("/") && !requestedNext.startsWith("//") ? requestedNext : "/overview";

fetch("/api/me").then((response) => {
    if (response.ok) {
        window.location.replace(next);
    }
}).catch(() => {});

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    statusLine.textContent = "";
    const body = new URLSearchParams(new FormData(form));
    const response = await fetch("/login", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
        statusLine.textContent = data.message || "Не удалось войти";
        return;
    }
    window.location.replace(next);
});
